plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.myhome.tv"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.myhome.tv"
        minSdk = 23
        targetSdk = 35
        // رقم النسخة يزيد تلقائياً مع كل بناء على GitHub، عشان التحديث يركب فوق القديم
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "2.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
    }

    // توقيع ثابت من الخزنة السرية في GitHub (مو موجود في الكود):
    // كل نسخة جديدة تتثبت فوق القديمة بدون ما تنمسح بياناتك
    val keystorePath = System.getenv("SIGNING_KEYSTORE")
    val keystorePass = System.getenv("SIGNING_PASSWORD") ?: ""
    signingConfigs {
        if (keystorePath != null) {
            create("fixed") {
                storeFile = file(keystorePath)
                storePassword = keystorePass
                keyAlias = "abu"
                keyPassword = keystorePass
            }
        }
    }

    buildTypes {
        debug {
            if (keystorePath != null) signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            if (keystorePath != null) signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

// الاختبارات التلقائية تشتغل قبل كل بناء — إذا فشل اختبار، ما يطلع التطبيق
tasks.matching { it.name == "assembleDebug" }.configureEach {
    dependsOn("testDebugUnitTest")
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("androidx.core:core-ktx:1.13.1")
    // تشفير المفاتيح والرمز السري داخل التلفاز
    implementation("androidx.security:security-crypto:1.0.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // مشغّل الفيديو (يدعم MP4 و HLS/m3u8 و DASH)
    val media3 = "1.4.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-exoplayer-dash:$media3")
    implementation("androidx.media3:media3-ui:$media3")

    // تحميل الصور
    implementation("io.coil-kt:coil-compose:2.7.0")

    // اختبارات تلقائية تشتغل مع كل بناء
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
