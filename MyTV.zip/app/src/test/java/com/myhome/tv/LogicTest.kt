package com.myhome.tv

import com.myhome.tv.data.Assistant
import com.myhome.tv.data.ContentItem
import com.myhome.tv.data.ContentType
import com.myhome.tv.data.Episode
import com.myhome.tv.data.LinkInspector
import com.myhome.tv.data.M3uParser
import com.myhome.tv.data.Progress
import com.myhome.tv.data.Storage
import com.myhome.tv.data.Subtitles
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** اختبارات تلقائية لأهم أجزاء التطبيق — تشتغل على GitHub مع كل بناء */
class LogicTest {

    @Test fun srtParsing() {
        val srt = "1\n00:00:01,000 --> 00:00:03,500\nHello <i>there</i>\n\n2\n00:00:04,000 --> 00:00:06,000\nHow are you?\nFine.\n"
        val cues = Subtitles.parse(srt)
        assertEquals(2, cues.size)
        assertEquals(1000L, cues[0].start)
        assertEquals(3500L, cues[0].end)
        assertEquals("Hello there", cues[0].text)
        assertEquals("How are you?\nFine.", cues[1].text)
    }

    @Test fun vttParsingAndRoundTrip() {
        val vtt = "WEBVTT\n\n00:01.000 --> 00:02.000 align:start\nHi\n\n01:00:00.500 --> 01:00:02.000\nBye"
        val cues = Subtitles.parse(vtt)
        assertEquals(2, cues.size)
        assertEquals(3_600_500L, cues[1].start)
        val again = Subtitles.parse(Subtitles.toSrt(cues))
        assertEquals(cues, again)
    }

    @Test fun arabicDetection() {
        assertTrue(Subtitles.isArabic("مرحبا كيف حالك"))
        assertFalse(Subtitles.isArabic("Hello, how are you?"))
    }

    @Test fun m3uImport() {
        val m3u = "#EXTM3U\n#EXTINF:-1 tvg-logo=\"http://l.png\" group-title=\"رياضة\",SSC 1\nhttp://x/1.m3u8\n#EXTINF:-1,MBC\nhttp://x/2.m3u8\n"
        val list = M3uParser.parse(m3u)
        assertEquals(2, list.size)
        assertEquals("SSC 1", list[0].title)
        assertEquals("رياضة", list[0].category)
        assertEquals("http://l.png", list[0].poster)
        assertEquals(ContentType.CHANNEL, list[1].type)
    }

    @Test fun linkNames() {
        assertEquals("The Dark Knight", LinkInspector.nameFromUrl("https://example.com/movies/The_Dark-Knight.mp4?token=1"))
        assertEquals("shahid.net", LinkInspector.nameFromUrl("https://www.shahid.net/"))
    }

    @Test fun pinHashing() {
        val stored = Storage.hashPin("2580")
        assertTrue(Storage.verifyPin("2580", stored))
        assertFalse(Storage.verifyPin("2581", stored))
        assertFalse(stored.contains("2580"))
    }

    @Test fun assistantReplyParsing() {
        val r = Assistant.parse("بحثت لك.\n{\"reply\":\"تمام\",\"actions\":[{\"type\":\"play\",\"id\":\"abc\"}],\"remember\":\"يحب الأكشن\"}")
        assertEquals("تمام", r.text)
        assertEquals(1, r.actions.size)
        assertEquals("play", r.actions[0].type)
        assertEquals("abc", r.actions[0].id)
        assertEquals("يحب الأكشن", r.remember)
        val plain = Assistant.parse("رد بدون JSON")
        assertEquals("رد بدون JSON", plain.text)
        assertTrue(plain.actions.isEmpty())
    }

    @Test fun libraryJsonRoundTrip() {
        val item = ContentItem(
            type = ContentType.SERIES, title = "مسلسل", subtitleUrl = "",
            episodes = listOf(Episode(1, 1, "", "http://a/1.mp4", "http://a/1.srt"), Episode(1, 2, "ح2", "http://a/2.mp4"))
        )
        val back = ContentItem.fromJson(item.toJson())
        assertEquals(item, back)
    }

    @Test fun nextEpisode() {
        val item = ContentItem(
            type = ContentType.SERIES, title = "x",
            episodes = listOf(Episode(2, 1, "", "u3"), Episode(1, 2, "", "u2"), Episode(1, 1, "", "u1"))
        )
        assertEquals(Episode(1, 2, "", "u2"), item.nextEpisode(Episode(1, 1, "", "u1")))
        assertEquals(Episode(2, 1, "", "u3"), item.nextEpisode(Episode(1, 2, "", "u2")))
        assertNull(item.nextEpisode(Episode(2, 1, "", "u3")))
        assertEquals("id#S1E2", Progress.key("id", Episode(1, 2, "", "")))
    }
}
