package com.myhome.tv.data

/**
 * يقرأ ملفات قوائم القنوات M3U / M3U8:
 * #EXTINF:-1 tvg-logo="..." group-title="رياضة",اسم القناة
 * http://.../stream.m3u8
 */
object M3uParser {
    fun parse(text: String): List<ContentItem> {
        val out = mutableListOf<ContentItem>()
        var name = ""
        var logo = ""
        var group = ""
        val base = System.currentTimeMillis()
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    name = line.substringAfterLast(",", "").trim()
                    logo = attr(line, "tvg-logo")
                    group = attr(line, "group-title")
                }
                line.isNotEmpty() && !line.startsWith("#") -> {
                    out += ContentItem(
                        type = ContentType.CHANNEL,
                        title = name.ifBlank { "قناة ${out.size + 1}" },
                        url = line,
                        poster = logo,
                        category = group,
                        // ترتيب ثابت حسب الملف
                        addedAt = base - out.size
                    )
                    name = ""; logo = ""; group = ""
                }
            }
        }
        return out
    }

    private fun attr(line: String, key: String): String =
        Regex("$key=\"([^\"]*)\"", RegexOption.IGNORE_CASE).find(line)?.groupValues?.get(1)?.trim() ?: ""
}
