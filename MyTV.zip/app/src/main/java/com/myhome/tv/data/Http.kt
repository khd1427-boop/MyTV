package com.myhome.tv.data

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** اتصال إنترنت بسيط بدون مكتبات إضافية. يُستدعى دائماً من خيط خلفي. */
object Http {
    fun get(url: String, headers: Map<String, String> = emptyMap()): String =
        request("GET", url, null, headers)

    fun postJson(url: String, body: String, headers: Map<String, String> = emptyMap()): String =
        request("POST", url, body, headers + ("content-type" to "application/json"))

    private fun request(method: String, url: String, body: String?, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 15_000
            c.readTimeout = 90_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android TV) MyTV/1.0")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP $code ${text.take(300)}")
            return text
        } finally {
            c.disconnect()
        }
    }
}
