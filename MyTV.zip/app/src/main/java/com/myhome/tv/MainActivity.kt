package com.myhome.tv

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myhome.tv.data.Assistant
import com.myhome.tv.data.ContentItem
import com.myhome.tv.data.ContentType
import com.myhome.tv.player.PlayerActivity
import com.myhome.tv.player.WebActivity
import com.myhome.tv.ui.Accent
import com.myhome.tv.ui.Accent2
import com.myhome.tv.ui.AccentBrush
import com.myhome.tv.ui.Gold
import com.myhome.tv.ui.AdminScreen
import com.myhome.tv.ui.AssistantScreen
import com.myhome.tv.ui.Bg
import com.myhome.tv.ui.DetailsScreen
import com.myhome.tv.ui.EditScreen
import com.myhome.tv.ui.FocusBox
import com.myhome.tv.ui.HomeScreen
import com.myhome.tv.ui.MyTvTheme
import com.myhome.tv.ui.SearchScreen
import com.myhome.tv.ui.SettingsScreen
import com.myhome.tv.ui.Surf

enum class Tab { HOME, MOVIES, SERIES, CHANNELS, WEBSITES }

data class PlayRequest(
    val itemId: String,
    val season: Int = 0,
    val episode: Int = 0,
    /** -1 = كمّل من مكان التوقف */
    val startAt: Long = -1
)

sealed interface Screen {
    data class Browse(val tab: Tab) : Screen
    data class Details(val id: String) : Screen
    data class Search(val query: String = "") : Screen
    data object AssistantChat : Screen
    data object Admin : Screen
    data class Edit(val id: String?) : Screen
    data object Settings : Screen
}

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyTvTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(color = Bg, contentColor = Color.White, modifier = Modifier.fillMaxSize()) {
                        App(vm)
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // تحديث "تابع المشاهدة" بعد الرجوع من المشغّل
        vm.reloadProgress()
        if (intent?.getBooleanExtra(EXTRA_VOICE, false) == true) {
            intent.removeExtra(EXTRA_VOICE)
            vm.pendingVoice = true
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    // زر المايك / البحث في الريموت يفتح المساعد مباشرة
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (isVoiceKey(keyCode)) {
            vm.pendingVoice = true
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    companion object {
        const val EXTRA_VOICE = "voice"

        fun isVoiceKey(keyCode: Int) =
            keyCode == KeyEvent.KEYCODE_SEARCH ||
                keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
                keyCode == KeyEvent.KEYCODE_ASSIST
    }
}

private data class NavEntry(val screen: Screen, val icon: ImageVector, val label: String)

private val navEntries = listOf(
    NavEntry(Screen.Browse(Tab.HOME), Icons.Filled.Home, "الرئيسية"),
    NavEntry(Screen.Browse(Tab.MOVIES), Icons.Filled.Movie, "أفلام"),
    NavEntry(Screen.Browse(Tab.SERIES), Icons.Filled.Tv, "مسلسلات"),
    NavEntry(Screen.Browse(Tab.CHANNELS), Icons.Filled.LiveTv, "قنوات مباشرة"),
    NavEntry(Screen.Browse(Tab.WEBSITES), Icons.Filled.Language, "مواقع"),
    NavEntry(Screen.Search(), Icons.Filled.Search, "بحث"),
    NavEntry(Screen.AssistantChat, Icons.Filled.SmartToy, "مساعد أبو معاذ"),
    NavEntry(Screen.Admin, Icons.Filled.AddCircle, "إدارة المحتوى"),
    NavEntry(Screen.Settings, Icons.Filled.Settings, "الإعدادات")
)

private fun startPlayer(context: Context, req: PlayRequest) {
    context.startActivity(PlayerActivity.intent(context, req.itemId, req.season, req.episode, req.startAt))
}

@Composable
fun App(vm: AppViewModel) {
    val context = LocalContext.current
    val stack = remember { mutableStateListOf<Screen>(Screen.Browse(Tab.HOME)) }
    val current = stack.last()

    fun push(s: Screen) { stack.add(s) }
    fun navigate(s: Screen) {
        stack.clear()
        stack.add(Screen.Browse(Tab.HOME))
        if (s != Screen.Browse(Tab.HOME)) stack.add(s)
    }
    fun pop() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }

    BackHandler(enabled = stack.size > 1) { pop() }

    // زر المايك في الريموت: افتح شاشة المساعد (والشاشة تشغّل المايك)
    LaunchedEffect(vm.pendingVoice) {
        if (vm.pendingVoice && current != Screen.AssistantChat) navigate(Screen.AssistantChat)
    }

    fun play(req: PlayRequest) = startPlayer(context, req)

    fun playItem(item: ContentItem) {
        if (item.type == ContentType.WEBSITE) {
            context.startActivity(WebActivity.intent(context, item.url, item.title))
            return
        }
        if (item.type == ContentType.SERIES) {
            val r = vm.resumeEpisode(item)
            if (r == null) {
                Toast.makeText(context, "المسلسل ما فيه حلقات", Toast.LENGTH_SHORT).show()
                return
            }
            play(PlayRequest(item.id, r.first.season, r.first.number))
        } else {
            play(PlayRequest(item.id))
        }
    }

    fun open(item: ContentItem) {
        if (item.type == ContentType.CHANNEL || item.type == ContentType.WEBSITE) playItem(item)
        else push(Screen.Details(item.id))
    }

    // تنفيذ أوامر المساعد الذكي
    val onAction: (Assistant.Action) -> Unit = { a ->
        when (a.type) {
            "play" -> vm.item(a.id)?.let { target ->
                if (target.type == ContentType.SERIES && a.season > 0) {
                    play(PlayRequest(target.id, a.season, a.episode.coerceAtLeast(1)))
                } else {
                    playItem(target)
                }
            }
            "open" -> vm.item(a.id)?.let { open(it) }
            "search" -> push(Screen.Search(a.query))
            "browse" -> when (a.query.uppercase()) {
                "MOVIE" -> navigate(Screen.Browse(Tab.MOVIES))
                "SERIES" -> navigate(Screen.Browse(Tab.SERIES))
                "CHANNEL" -> navigate(Screen.Browse(Tab.CHANNELS))
                "WEBSITE" -> navigate(Screen.Browse(Tab.WEBSITES))
                else -> navigate(Screen.Browse(Tab.HOME))
            }
            else -> Unit
        }
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
    // توهج خفيف في الخلفية
    Box(
        Modifier
            .align(Alignment.TopEnd)
            .size(700.dp)
            .background(Brush.radialGradient(listOf(Accent.copy(alpha = 0.16f), Color.Transparent)))
    )
    Box(
        Modifier
            .align(Alignment.BottomStart)
            .size(600.dp)
            .background(Brush.radialGradient(listOf(Accent2.copy(alpha = 0.10f), Color.Transparent)))
    )
    Row(Modifier.fillMaxSize()) {
        SideNav(stack.toList(), onSelect = { navigate(it) }, onVoice = { vm.pendingVoice = true })
        Box(
            Modifier
                .weight(1f)
                .fillMaxHeight()
        ) {
            when (val s = current) {
                is Screen.Browse -> key(s.tab) {
                    HomeScreen(
                        vm, s.tab,
                        onOpen = { open(it) },
                        onPlay = { playItem(it) },
                        onAdd = { navigate(Screen.Admin) }
                    )
                }
                is Screen.Details -> DetailsScreen(vm, s.id, onPlay = { play(it) })
                is Screen.Search -> key(s.query) { SearchScreen(vm, s.query, onOpen = { open(it) }) }
                Screen.AssistantChat -> AssistantScreen(vm, onAction)
                Screen.Admin -> AdminScreen(vm, onEdit = { push(Screen.Edit(it)) })
                is Screen.Edit -> key(s.id) { EditScreen(vm, s.id, onDone = { pop() }) }
                Screen.Settings -> SettingsScreen(vm)
            }
        }
    }
    }
}

@Composable
private fun SideNav(stack: List<Screen>, onSelect: (Screen) -> Unit, onVoice: () -> Unit) {
    val firstFocus = remember { FocusRequester() }
    // القسم المختار = آخر شاشة رئيسية في المسار
    val selected = stack.lastOrNull { s -> navEntries.any { sameSection(it.screen, s) } }

    Column(
        Modifier
            .width(230.dp)
            .fillMaxHeight()
            .background(Brush.verticalGradient(listOf(Surf, Bg)))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 14.dp)
    ) {
        // الشعار
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp)) {
            Box(
                Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(AccentBrush),
                contentAlignment = Alignment.Center
            ) {
                Text("م", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color.White)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("أبو معاذ", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color.White)
                Text("تلفازك الذكي", fontSize = 12.sp, color = Gold)
            }
        }
        Spacer(Modifier.height(12.dp))
        // زر المايك السريع
        FocusBox(
            onClick = onVoice,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            focusedScale = 1.04f,
            backgroundBrush = AccentBrush,
            focusedBackground = Color.White,
            glow = true
        ) { focused ->
            Row(
                Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Mic, contentDescription = null, tint = if (focused) Color.Black else Color.White, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(10.dp))
                Text("تكلّم مع المساعد", color = if (focused) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        navEntries.forEachIndexed { i, entry ->
            val isSelected = selected != null && sameSection(entry.screen, selected)
            FocusBox(
                onClick = { onSelect(entry.screen) },
                modifier = (if (i == 0) Modifier.focusRequester(firstFocus) else Modifier)
                    .fillMaxWidth()
                    .padding(vertical = 1.dp),
                shape = RoundedCornerShape(10.dp),
                focusedScale = 1.03f,
                background = if (isSelected) Accent.copy(alpha = 0.22f) else Color.Transparent,
                focusedBackground = Color.White
            ) { focused ->
                Row(
                    Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        entry.icon,
                        contentDescription = null,
                        tint = when {
                            focused -> Color.Black
                            isSelected -> Accent2
                            else -> Color.White
                        },
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        entry.label,
                        color = if (focused) Color.Black else Color.White,
                        fontSize = 15.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }
}

private fun sameSection(a: Screen, b: Screen): Boolean = when (a) {
    is Screen.Browse -> a == b
    else -> a::class == b::class
}
