package com.myhome.tv.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myhome.tv.AppViewModel
import com.myhome.tv.data.Assistant

private val suggestions = listOf(
    "كمّل آخر شيء كنت أشوفه",
    "اقترح لي فيلم يناسب سهرة الليلة",
    "متى مباراة الهلال الجاية؟",
    "شغّل قناة رياضية",
    "أبغى شيء خفيف للعائلة",
    "وش المسلسلات اللي عندي؟"
)

@Composable
fun AssistantScreen(vm: AppViewModel, onAction: (Assistant.Action) -> Unit) {
    if (vm.assistantLocked) {
        PinGate(vm)
        return
    }
    var input by remember { mutableStateOf("") }
    val context = LocalContext.current
    val listState = rememberLazyListState()

    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) vm.askAssistant(spoken, onAction)
    }

    fun startVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "تكلّم... وش تبغى أسوي؟")
        try {
            voiceLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "جهازك ما يدعم الأوامر الصوتية، اكتب طلبك", Toast.LENGTH_LONG).show()
        }
    }

    fun send() {
        if (input.isBlank()) return
        val t = input
        input = ""
        vm.askAssistant(t, onAction)
    }

    // زر المايك في الريموت
    LaunchedEffect(vm.pendingVoice) {
        if (vm.pendingVoice) {
            vm.pendingVoice = false
            startVoice()
        }
    }

    val count = vm.chat.size + (if (vm.aiBusy) 1 else 0)
    LaunchedEffect(count) {
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    Column(Modifier.fillMaxSize().padding(32.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                ScreenHeader("مساعد أبو معاذ", "اضغط زر المايك في الريموت وتكلّم، أو اكتب طلبك")
            }
            if (vm.speaking) {
                TvButton("إيقاف الصوت", { vm.stopSpeaking() }, icon = Icons.Filled.VolumeOff)
                Spacer(Modifier.width(10.dp))
            }
            TvButton("محادثة جديدة", { vm.clearChat() }, icon = Icons.Filled.Refresh)
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            if (vm.chat.isEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("جرّب:", color = TextDim, fontSize = 16.sp)
                        suggestions.forEach { s ->
                            TvButton(s, { vm.askAssistant(s, onAction) })
                        }
                    }
                }
            }
            itemsIndexed(vm.chat) { index, m ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (m.fromUser) Arrangement.Start else Arrangement.End
                ) {
                    Box(
                        Modifier
                            .widthIn(max = 620.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .then(
                                if (m.fromUser) Modifier.background(AccentBrush)
                                else Modifier.background(Surf2)
                            )
                            .padding(horizontal = 18.dp, vertical = 12.dp)
                    ) {
                        Text(vm.visibleText(index, m.text), color = Color.White, fontSize = 17.sp, lineHeight = 26.sp)
                    }
                }
            }
            if (vm.aiBusy) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        var dots by remember { mutableStateOf(1) }
                        LaunchedEffect(Unit) {
                            while (true) {
                                kotlinx.coroutines.delay(400)
                                dots = dots % 3 + 1
                            }
                        }
                        Text("المساعد يفكّر" + ".".repeat(dots) + " (البحث في الإنترنت ممكن ياخذ ثواني)", color = Accent2, fontSize = 16.sp)
                    }
                }
            }
        }

        if (vm.speaking) {
            Text("🔊 المساعد يتكلّم...", color = Gold, fontSize = 15.sp)
        }
        if (vm.arabicVoiceMissing && vm.settings.voiceReply) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("الصوت العربي مو مثبّت في التلفاز، فالمساعد بيكتب بدون صوت", color = Gold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                TvButton("ثبّت الصوت العربي", {
                    try {
                        context.startActivity(
                            Intent(android.speech.tts.TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(context, "ثبّت تطبيق \"Speech Services by Google\" من المتجر", Toast.LENGTH_LONG).show()
                    }
                })
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Field(input, { input = it }, "اكتب طلبك...", Modifier.weight(1f), onDone = { send() })
            TvButton("إرسال", { send() }, icon = Icons.Filled.Send)
            TvButton("تكلّم", { startVoice() }, icon = Icons.Filled.Mic, primary = true)
        }
    }
}
