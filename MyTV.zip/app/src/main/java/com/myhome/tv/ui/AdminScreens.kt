package com.myhome.tv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myhome.tv.AppViewModel
import com.myhome.tv.data.ContentItem
import com.myhome.tv.data.ContentType
import com.myhome.tv.data.Episode
import com.myhome.tv.data.LinkInspector
import kotlinx.coroutines.launch

// =====================================================================
//  قائمة المحتوى (إدارة)
// =====================================================================
@Composable
fun AdminScreen(vm: AppViewModel, onEdit: (String?) -> Unit) {
    if (vm.isLocked) {
        PinGate(vm)
        return
    }
    var filter by remember { mutableStateOf<ContentType?>(null) }
    var showImport by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<String?>(null) }
    val list = vm.items.filter { filter == null || it.type == filter }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(32.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            ScreenHeader(
                "إدارة المحتوى",
                "${vm.items.count { it.type == ContentType.MOVIE }} فيلم • " +
                    "${vm.items.count { it.type == ContentType.SERIES }} مسلسل • " +
                    "${vm.items.count { it.type == ContentType.CHANNEL }} قناة • " +
                    "${vm.items.count { it.type == ContentType.WEBSITE }} موقع"
            )
        }
        item { SmartAddPanel(vm) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TvButton("إضافة يدوية بالتفصيل", { onEdit(null) }, icon = Icons.Filled.Add)
                TvButton(if (showImport) "إخفاء الاستيراد" else "استيراد قنوات M3U", { showImport = !showImport }, icon = Icons.Filled.List)
            }
        }
        if (showImport) item { ImportPanel(vm) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 8.dp)) {
                TvButton("الكل", { filter = null }, primary = filter == null)
                ContentType.entries.forEach { t ->
                    TvButton(t.label, { filter = t }, primary = filter == t)
                }
            }
        }
        if (list.isEmpty()) {
            item { Text("ما فيه شيء هنا بعد", color = TextDim, modifier = Modifier.padding(16.dp)) }
        }
        items(list, key = { it.id }) { item ->
            AdminRow(
                item = item,
                confirming = confirmDelete == item.id,
                onEdit = { onEdit(item.id) },
                onDelete = {
                    if (confirmDelete == item.id) {
                        vm.delete(item.id)
                        confirmDelete = null
                    } else {
                        confirmDelete = item.id
                    }
                }
            )
        }
    }
}

@Composable
private fun AdminRow(item: ContentItem, confirming: Boolean, onEdit: () -> Unit, onDelete: () -> Unit) {
    val wide = item.type == ContentType.CHANNEL || item.type == ContentType.WEBSITE
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Surf)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Poster(
            item,
            Modifier
                .width(if (wide) 96.dp else 56.dp)
                .aspectRatio(if (wide) 16f / 9f else 2f / 3f)
                .clip(RoundedCornerShape(8.dp)),
            fit = wide
        )
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val info = listOf(
                item.type.single,
                item.category,
                if (item.type == ContentType.SERIES) "${item.episodes.size} حلقة" else ""
            ).filter { it.isNotBlank() }.joinToString(" • ")
            Text(info, fontSize = 13.sp, color = TextDim)
        }
        TvButton("تعديل", onEdit, icon = Icons.Filled.Edit)
        Spacer(Modifier.width(10.dp))
        TvButton(if (confirming) "متأكد؟ اضغط مرة ثانية" else "حذف", onDelete, icon = Icons.Filled.Delete)
    }
}

/** الإضافة الذكية: الصق أي رابط والتطبيق يتعرّف عليه */
@Composable
private fun SmartAddPanel(vm: AppViewModel) {
    var url by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(Accent.copy(alpha = 0.25f), Surf)))
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("✨ إضافة ذكية", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
        Text(
            "الصق أي رابط: قناة بث، قائمة قنوات M3U، فيلم، أو موقع. التطبيق يفحصه ويعرف نوعه ويضيفه في مكانه.",
            color = TextDim, fontSize = 14.sp
        )
        Field(url, { url = it; message = null }, "الرابط *")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Field(title, { title = it }, "الاسم (اختياري)", Modifier.weight(1f))
            Field(category, { category = it }, "التصنيف (اختياري)", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TvButton(if (busy) "جاري الفحص..." else "افحص وأضف", {
                if (!busy && url.isNotBlank()) {
                    busy = true
                    message = null
                    scope.launch {
                        message = vm.smartAdd(url, title, category)
                        if (message?.contains("✓") == true) { url = ""; title = "" }
                        busy = false
                    }
                }
            }, icon = Icons.Filled.AutoAwesome, primary = true)
            TvButton("افحص بس", {
                if (!busy && url.isNotBlank()) {
                    busy = true
                    scope.launch {
                        val r = vm.inspectLink(url)
                        message = "النوع: " + when (r.kind) {
                            LinkInspector.Kind.PLAYLIST -> "قائمة قنوات"
                            LinkInspector.Kind.LIVE -> "بث مباشر"
                            LinkInspector.Kind.VIDEO -> "فيلم / فيديو"
                            LinkInspector.Kind.WEBSITE -> "موقع"
                        } + " — " + r.detail
                        busy = false
                    }
                }
            })
        }
        message?.let { Text(it, color = if (it.contains("✓")) Accent2 else Gold, fontSize = 15.sp) }
    }
}

@Composable
private fun ImportPanel(vm: AppViewModel) {
    var url by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Surf)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("استيراد قائمة قنوات (M3U)", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("حط رابط ملف القائمة، أو الصق محتواه. القنوات المكررة ما تنضاف مرتين.", color = TextDim, fontSize = 14.sp)
        Field(url, { url = it }, "رابط ملف M3U")
        Field(text, { text = it }, "أو الصق محتوى الملف هنا", multiline = true)
        Field(category, { category = it }, "تصنيف لكل القنوات (اختياري)")
        TvButton(if (busy) "جاري الاستيراد..." else "استيراد", {
            if (!busy && (url.isNotBlank() || text.isNotBlank())) {
                busy = true
                message = null
                scope.launch {
                    message = try {
                        val n = if (url.isNotBlank()) vm.importM3u(url.trim(), true, category.trim())
                        else vm.importM3u(text, false, category.trim())
                        if (n == 0) "ما لقيت قنوات جديدة في القائمة" else "تمت إضافة $n قناة ✓"
                    } catch (e: Exception) {
                        "فشل الاستيراد: ${e.message}"
                    }
                    busy = false
                }
            }
        }, icon = Icons.Filled.Add, primary = true)
        message?.let { Text(it, color = Accent2, fontSize = 15.sp) }
    }
}

// =====================================================================
//  إضافة / تعديل عنصر
// =====================================================================
@Composable
fun EditScreen(vm: AppViewModel, id: String?, onDone: () -> Unit) {
    val existing = remember(id) { vm.item(id) }
    var type by remember { mutableStateOf(existing?.type ?: ContentType.MOVIE) }
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var url by remember { mutableStateOf(existing?.url ?: "") }
    var poster by remember { mutableStateOf(existing?.poster ?: "") }
    var backdrop by remember { mutableStateOf(existing?.backdrop ?: "") }
    var description by remember { mutableStateOf(existing?.description ?: "") }
    var category by remember { mutableStateOf(existing?.category ?: "") }
    var year by remember { mutableStateOf(existing?.year ?: "") }
    var rating by remember { mutableStateOf(existing?.rating ?: "") }
    var subtitleUrl by remember { mutableStateOf(existing?.subtitleUrl ?: "") }
    var epSub by remember { mutableStateOf("") }
    val episodes = remember { mutableStateListOf<Episode>().apply { existing?.episodes?.let { addAll(it) } } }

    var epSeason by remember { mutableStateOf("1") }
    var epNumber by remember { mutableStateOf("") }
    var epTitle by remember { mutableStateOf("") }
    var epUrl by remember { mutableStateOf("") }
    var bulkSeason by remember { mutableStateOf("1") }
    var bulk by remember { mutableStateOf("") }

    var status by remember { mutableStateOf<String?>(null) }
    var loadingMeta by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun fetchMeta() {
        if (loadingMeta) return
        if (vm.settings.tmdbKey.isBlank()) { status = "أضف مفتاح TMDB من الإعدادات أول"; return }
        if (title.isBlank()) { status = "اكتب الاسم أول"; return }
        loadingMeta = true
        status = "جاري البحث..."
        scope.launch {
            try {
                val m = vm.fetchMeta(title.trim(), type)
                if (m == null) {
                    status = "ما لقيت نتيجة بهذا الاسم"
                } else {
                    if (m.poster.isNotBlank()) poster = m.poster
                    if (m.backdrop.isNotBlank()) backdrop = m.backdrop
                    if (m.description.isNotBlank()) description = m.description
                    if (m.year.isNotBlank()) year = m.year
                    if (m.rating.isNotBlank()) rating = m.rating
                    status = "تم جلب البيانات ✓"
                }
            } catch (e: Exception) {
                status = "خطأ: ${e.message}"
            }
            loadingMeta = false
        }
    }

    fun addEpisode() {
        val s = epSeason.toIntOrNull() ?: 1
        val n = epNumber.toIntOrNull() ?: ((episodes.filter { it.season == s }.maxOfOrNull { it.number } ?: 0) + 1)
        if (epUrl.isBlank()) { status = "حط رابط الحلقة"; return }
        episodes.removeAll { it.season == s && it.number == n }
        episodes.add(Episode(s, n, epTitle.trim(), epUrl.trim(), epSub.trim()))
        epNumber = ""; epTitle = ""; epUrl = ""; epSub = ""
        status = "انضافت الحلقة $n من الموسم $s ✓"
    }

    fun addBulk() {
        val s = bulkSeason.toIntOrNull() ?: 1
        var n = episodes.filter { it.season == s }.maxOfOrNull { it.number } ?: 0
        var added = 0
        bulk.lines().map { it.trim() }.filter { it.isNotEmpty() }.forEach { line ->
            n++
            val parts = line.split("|").map { it.trim() }
            val epT = if (parts.size >= 2) parts[0] else ""
            val epU = if (parts.size >= 2) parts[1] else parts[0]
            val epS = if (parts.size >= 3) parts[2] else ""
            episodes.add(Episode(s, n, epT, epU, epS))
            added++
        }
        bulk = ""
        status = "انضافت $added حلقة للموسم $s ✓"
    }

    fun save() {
        if (title.isBlank()) { status = "اكتب الاسم"; return }
        if (type != ContentType.SERIES && url.isBlank()) { status = "حط الرابط"; return }
        if (type == ContentType.SERIES && episodes.isEmpty()) { status = "أضف حلقة وحدة على الأقل"; return }
        val base = existing ?: ContentItem(type = type, title = title.trim())
        vm.upsert(
            base.copy(
                type = type,
                title = title.trim(),
                url = if (type == ContentType.SERIES) "" else url.trim(),
                poster = poster.trim(),
                backdrop = backdrop.trim(),
                description = description.trim(),
                category = category.trim(),
                year = year.trim(),
                rating = rating.trim(),
                subtitleUrl = if (type == ContentType.MOVIE) subtitleUrl.trim() else "",
                episodes = if (type == ContentType.SERIES) episodes.toList() else emptyList()
            )
        )
        onDone()
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenHeader(if (existing == null) "إضافة محتوى" else "تعديل: ${existing.title}") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ContentType.entries.forEach { t -> TvButton(t.single, { type = t }, primary = type == t) }
            }
        }
        item { Field(title, { title = it }, "الاسم *") }
        if (type == ContentType.MOVIE || type == ContentType.SERIES) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TvButton(if (loadingMeta) "جاري الجلب..." else "جلب الصورة والوصف تلقائياً", { fetchMeta() }, icon = Icons.Filled.AutoAwesome)
                }
            }
        }
        if (type != ContentType.SERIES) {
            item {
                Field(
                    url, { url = it },
                    when (type) {
                        ContentType.CHANNEL -> "رابط البث المباشر (m3u8 أو غيره) *"
                        ContentType.WEBSITE -> "رابط الموقع *"
                        else -> "رابط الفيلم (mp4 أو m3u8 أو غيره) *"
                    }
                )
            }
            item {
                TvButton("اختبر الرابط", {
                    if (url.isNotBlank()) {
                        status = "جاري الفحص..."
                        scope.launch { status = vm.inspectLink(url).detail }
                    }
                })
            }
        }
        item { Field(category, { category = it }, "التصنيف (مثال: أكشن، رياضة، أطفال)") }
        item {
            Field(
                poster, { poster = it },
                when (type) {
                    ContentType.CHANNEL -> "رابط شعار القناة"
                    ContentType.WEBSITE -> "رابط شعار الموقع"
                    else -> "رابط صورة البوستر"
                }
            )
        }
        if (type == ContentType.MOVIE) {
            item { Field(subtitleUrl, { subtitleUrl = it }, "رابط ملف الترجمة srt أو vtt بأي لغة (اختياري، يترجم للعربي تلقائياً)") }
        }
        if (type == ContentType.MOVIE || type == ContentType.SERIES) {
            item { Field(backdrop, { backdrop = it }, "رابط صورة الخلفية العريضة") }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Field(year, { year = it }, "السنة", Modifier.weight(1f), number = true)
                    Field(rating, { rating = it }, "التقييم (من 10)", Modifier.weight(1f))
                }
            }
            item { Field(description, { description = it }, "الوصف / القصة", multiline = true) }
        }

        if (type == ContentType.SERIES) {
            item { SectionTitle("الحلقات (${episodes.size})") }
            val sorted = episodes.sortedWith(compareBy<Episode>({ it.season }, { it.number }))
            items(sorted) { ep ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Surf)
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("م${ep.season} • ح${ep.number}", color = Accent2, fontWeight = FontWeight.Bold, modifier = Modifier.width(110.dp))
                    Text(ep.displayTitle, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    TvButton("حذف", { episodes.remove(ep) }, icon = Icons.Filled.Delete)
                }
            }
            item {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Surf)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("إضافة حلقة", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Field(epSeason, { epSeason = it }, "الموسم", Modifier.weight(1f), number = true)
                        Field(epNumber, { epNumber = it }, "رقم الحلقة (تلقائي لو فاضي)", Modifier.weight(1f), number = true)
                    }
                    Field(epTitle, { epTitle = it }, "عنوان الحلقة (اختياري)")
                    Field(epUrl, { epUrl = it }, "رابط الحلقة *")
                    Field(epSub, { epSub = it }, "رابط ترجمة الحلقة srt/vtt (اختياري)")
                    TvButton("إضافة الحلقة", { addEpisode() }, icon = Icons.Filled.Add)
                }
            }
            item {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Surf)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("إضافة موسم كامل دفعة وحدة", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
                    Text("كل سطر = حلقة. اكتب الرابط بس، أو: عنوان الحلقة | الرابط | رابط الترجمة", color = TextDim, fontSize = 14.sp)
                    Field(bulkSeason, { bulkSeason = it }, "الموسم", Modifier.width(200.dp), number = true)
                    Field(bulk, { bulk = it }, "الروابط", multiline = true)
                    TvButton("إضافة كل الحلقات", { addBulk() }, icon = Icons.Filled.List)
                }
            }
        }

        item {
            status?.let { Text(it, color = Accent2, fontSize = 16.sp) }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TvButton("حفظ", { save() }, icon = Icons.Filled.Save, primary = true)
                TvButton("إلغاء", onDone)
            }
        }
    }
}
