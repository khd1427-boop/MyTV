package com.myhome.tv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.myhome.tv.AppViewModel
import com.myhome.tv.PlayRequest
import com.myhome.tv.data.ContentType
import com.myhome.tv.data.Progress

@Composable
fun DetailsScreen(vm: AppViewModel, id: String, onPlay: (PlayRequest) -> Unit) {
    val ci = vm.item(id)
    if (ci == null) {
        EmptyState("المحتوى غير موجود", "يمكن انحذف من إدارة المحتوى")
        return
    }
    val resume = if (ci.type == ContentType.SERIES) vm.resumeEpisode(ci) else null
    var season by remember(id) { mutableIntStateOf(resume?.first?.season ?: ci.seasons().firstOrNull() ?: 1) }

    Box(Modifier.fillMaxSize()) {
        val img = ci.backdrop.ifBlank { ci.poster }
        if (img.isNotBlank()) {
            AsyncImage(
                model = img,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().alpha(0.3f)
            )
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg.copy(alpha = 0.3f), Bg))))

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row {
                    Poster(
                        ci,
                        Modifier
                            .width(220.dp)
                            .aspectRatio(2f / 3f)
                            .clip(RoundedCornerShape(14.dp))
                    )
                    Spacer(Modifier.width(32.dp))
                    Column(Modifier.weight(1f)) {
                        Text(ci.title, fontSize = 40.sp, fontWeight = FontWeight.Black, color = Color.White)
                        val meta = listOf(
                            ci.type.single, ci.year,
                            ci.rating.takeIf { it.isNotBlank() }?.let { "★ $it" } ?: "",
                            ci.category,
                            if (ci.type == ContentType.SERIES) "${ci.seasons().size} مواسم • ${ci.episodes.size} حلقة" else ""
                        ).filter { it.isNotBlank() }.joinToString("  •  ")
                        Text(meta, fontSize = 16.sp, color = TextDim)
                        Spacer(Modifier.height(14.dp))
                        if (ci.description.isNotBlank()) {
                            Text(ci.description, fontSize = 17.sp, color = Color(0xFFE6E6F0), lineHeight = 26.sp)
                            Spacer(Modifier.height(20.dp))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            if (ci.type == ContentType.SERIES) {
                                if (resume != null) {
                                    val (ep, pos) = resume
                                    val label = (if (pos > 0) "متابعة" else "تشغيل") + " م${ep.season} • ح${ep.number}"
                                    TvButton(label, { onPlay(PlayRequest(ci.id, ep.season, ep.number)) }, icon = Icons.Filled.PlayArrow, primary = true)
                                }
                            } else {
                                val pos = vm.progressOf(ci.id)?.takeIf { !it.finished }?.position ?: 0L
                                if (pos > 0) {
                                    TvButton("متابعة من ${formatTime(pos)}", { onPlay(PlayRequest(ci.id)) }, icon = Icons.Filled.PlayArrow, primary = true)
                                    TvButton("من البداية", { onPlay(PlayRequest(ci.id, startAt = 0)) }, icon = Icons.Filled.Refresh)
                                } else {
                                    TvButton("تشغيل", { onPlay(PlayRequest(ci.id, startAt = 0)) }, icon = Icons.Filled.PlayArrow, primary = true)
                                }
                            }
                        }
                    }
                }
            }

            if (ci.type == ContentType.SERIES && ci.episodes.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(20.dp))
                    SectionTitle("المواسم")
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        items(ci.seasons()) { s ->
                            TvButton("الموسم $s", { season = s }, primary = s == season)
                        }
                    }
                    SectionTitle("الحلقات")
                }
                val eps = ci.sortedEpisodes().filter { it.season == season }
                items(eps) { ep ->
                    val p = vm.progressOf(Progress.key(ci.id, ep))
                    FocusBox(
                        onClick = { onPlay(PlayRequest(ci.id, ep.season, ep.number)) },
                        modifier = Modifier.fillMaxWidth(),
                        focusedScale = 1.02f,
                        background = Surf,
                        focusedBackground = Surf2
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Accent),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("${ep.number}", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
                            }
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f)) {
                                Text(ep.displayTitle, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                                when {
                                    p?.finished == true -> Text("تمت المشاهدة", fontSize = 13.sp, color = Accent2)
                                    p != null && p.position > 0 -> Text("وقفت عند ${formatTime(p.position)}", fontSize = 13.sp, color = TextDim)
                                }
                            }
                            if (p?.finished == true) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Accent2)
                            } else {
                                Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}
