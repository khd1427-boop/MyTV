package com.myhome.tv.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * الاتصال بالذكاء الاصطناعي: Claude (من Anthropic) أو Gemini (من Google، فيه باقة مجانية).
 * تختار من الإعدادات، وكل التطبيق (المساعد + ترجمة الأفلام) يستخدم نفس الاختيار.
 */
object LlmClient {
    const val CLAUDE = "claude"
    const val GEMINI = "gemini"

    /** هل فيه مفتاح للمزوّد المختار؟ */
    fun hasKey(s: AppSettings): Boolean =
        if (s.aiProvider == GEMINI) s.geminiKey.isNotBlank() else s.claudeKey.isNotBlank()

    fun providerName(s: AppSettings): String = if (s.aiProvider == GEMINI) "Gemini" else "Claude"

    /**
     * يرسل المحادثة ويرجّع نص الرد.
     * history: (fromUser, text) — آخر عنصر لازم يكون من المستخدم.
     * fast: نموذج أسرع وأرخص (للترجمة).
     */
    fun complete(
        s: AppSettings,
        system: String,
        history: List<Pair<Boolean, String>>,
        webSearch: Boolean,
        fast: Boolean = false,
        maxTokens: Int = 1500
    ): String = if (s.aiProvider == GEMINI) gemini(s, system, history, webSearch, fast, maxTokens)
    else claude(s, system, history, webSearch, fast, maxTokens)

    // ---------------- Claude ----------------
    private fun claude(
        s: AppSettings, system: String, history: List<Pair<Boolean, String>>,
        webSearch: Boolean, fast: Boolean, maxTokens: Int
    ): String {
        val messages = JSONArray()
        history.forEach { (user, text) ->
            messages.put(JSONObject().put("role", if (user) "user" else "assistant").put("content", text))
        }
        val texts = StringBuilder()
        repeat(3) {
            val body = JSONObject()
                .put("model", if (fast) AppSettings.FAST_MODEL else s.claudeModel)
                .put("max_tokens", maxTokens)
                .put("system", system)
                .put("messages", messages)
            if (webSearch) {
                body.put(
                    "tools",
                    JSONArray().put(
                        JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 3)
                    )
                )
            }
            val resp = JSONObject(
                Http.postJson(
                    "https://api.anthropic.com/v1/messages",
                    body.toString(),
                    mapOf("x-api-key" to s.claudeKey, "anthropic-version" to "2023-06-01")
                )
            )
            val content = resp.optJSONArray("content") ?: JSONArray()
            for (i in 0 until content.length()) {
                val block = content.optJSONObject(i) ?: continue
                if (block.optString("type") == "text") texts.append(block.optString("text"))
            }
            if (resp.optString("stop_reason") != "pause_turn") return texts.toString()
            messages.put(JSONObject().put("role", "assistant").put("content", content))
        }
        return texts.toString()
    }

    // ---------------- Gemini ----------------
    private fun gemini(
        s: AppSettings, system: String, history: List<Pair<Boolean, String>>,
        webSearch: Boolean, fast: Boolean, maxTokens: Int
    ): String {
        val contents = JSONArray()
        history.forEach { (user, text) ->
            contents.put(
                JSONObject()
                    .put("role", if (user) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", maxTokens))
        if (webSearch) {
            body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        }
        val model = if (fast) AppSettings.GEMINI_FAST_MODEL else s.geminiModel.ifBlank { AppSettings.GEMINI_MODEL }
        val resp = JSONObject(
            Http.postJson(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
                body.toString(),
                mapOf("x-goog-api-key" to s.geminiKey)
            )
        )
        val parts = resp.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.optJSONObject(i) ?: continue
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text", ""))
        }
        if (sb.isBlank()) {
            val reason = resp.optJSONObject("promptFeedback")?.optString("blockReason", "") ?: ""
            if (reason.isNotBlank()) throw IllegalStateException("Gemini رفض الطلب ($reason)")
        }
        return sb.toString()
    }
}
