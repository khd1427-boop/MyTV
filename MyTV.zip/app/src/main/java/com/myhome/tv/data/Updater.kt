package com.myhome.tv.data

import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * التحديث من داخل التطبيق: يتحقق من آخر نسخة منشورة على GitHub وينزّلها.
 * الأمان: ما ينزّل إلا من مستودعك، والأندرويد يرفض أي نسخة موقّعة بمفتاح غير مفتاحك.
 */
object Updater {
    const val REPO = "khd1427-boop/MyTV"

    data class Release(val version: Int, val apkUrl: String)

    fun latest(): Release? {
        val json = JSONObject(
            Http.get(
                "https://api.github.com/repos/$REPO/releases/latest",
                mapOf("Accept" to "application/vnd.github+json")
            )
        )
        val version = json.optString("tag_name").removePrefix("v").toIntOrNull() ?: return null
        val assets = json.optJSONArray("assets") ?: return null
        for (i in 0 until assets.length()) {
            val a = assets.optJSONObject(i) ?: continue
            val url = a.optString("browser_download_url")
            if (a.optString("name").endsWith(".apk") && url.startsWith("https://github.com/$REPO/")) {
                return Release(version, url)
            }
        }
        return null
    }

    fun download(url: String, target: File, onProgress: (Int) -> Unit) {
        if (!url.startsWith("https://github.com/$REPO/")) throw IOException("رابط غير موثوق")
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 20_000
            c.readTimeout = 60_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "AbuMuath-Updater")
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            val total = c.contentLengthLong
            val tmp = File(target.parentFile, target.name + ".part")
            var done = 0L
            var lastPct = -1
            c.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct != lastPct) {
                                lastPct = pct
                                onProgress(pct)
                            }
                        }
                    }
                }
            }
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) throw IOException("ما قدرت أحفظ الملف")
        } finally {
            c.disconnect()
        }
    }
}
