package com.myhome.tv.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.myhome.tv.data.ContentItem
import com.myhome.tv.data.ContentType

/**
 * صندوق يتكبّر ويتلوّن لما يوقف عليه الريموت — أساس كل الأزرار والبطاقات.
 */
@Composable
fun FocusBox(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(12.dp),
    focusedScale: Float = 1.06f,
    background: Color = Color.Transparent,
    focusedBackground: Color = background,
    content: @Composable BoxScope.(focused: Boolean) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) focusedScale else 1f, label = "focusScale")
    Box(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(if (focused) focusedBackground else background)
            .border(3.dp, if (focused) Color.White else Color.Transparent, shape)
            .clickable(onClick = onClick)
    ) {
        content(focused)
    }
}

@Composable
fun TvButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    primary: Boolean = false
) {
    FocusBox(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        focusedScale = 1.05f,
        background = if (primary) Accent else Surf2,
        focusedBackground = Color.White
    ) { focused ->
        val c = if (focused) Color.Black else Color.White
        Row(
            Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                Icon(icon, contentDescription = null, tint = c, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(8.dp))
            }
            Text(text, color = c, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

/** صورة البوستر، ولو ما فيه صورة يطلع تصميم بديل باسم العمل */
@Composable
fun Poster(item: ContentItem, modifier: Modifier = Modifier, fit: Boolean = false) {
    if (item.poster.isNotBlank()) {
        Box(modifier.background(Surf2)) {
            AsyncImage(
                model = item.poster,
                contentDescription = item.title,
                contentScale = if (fit) ContentScale.Fit else ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(if (fit) 12.dp else 0.dp)
            )
        }
    } else {
        Box(
            modifier.background(Brush.linearGradient(listOf(Accent.copy(alpha = 0.8f), Surf2))),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    when (item.type) {
                        ContentType.MOVIE -> Icons.Filled.Movie
                        ContentType.SERIES -> Icons.Filled.Tv
                        ContentType.CHANNEL -> Icons.Filled.LiveTv
                    },
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.size(36.dp)
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    item.title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    maxLines = 3,
                    modifier = Modifier.padding(horizontal = 10.dp)
                )
            }
        }
    }
}

@Composable
fun PosterCard(item: ContentItem, progress: Float, onClick: () -> Unit, modifier: Modifier = Modifier.width(150.dp)) {
    Column(modifier) {
        FocusBox(
            onClick = onClick,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f),
            focusedScale = 1.08f,
            background = Surf2
        ) {
            Poster(item, Modifier.fillMaxSize())
            if (progress > 0f) {
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .height(5.dp)
                        .background(Color.Black.copy(alpha = 0.6f))
                ) {
                    Box(
                        Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progress)
                            .background(Accent)
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, color = Color(0xFFE0E0EE))
    }
}

@Composable
fun ChannelCard(item: ContentItem, onClick: () -> Unit, modifier: Modifier = Modifier.width(210.dp)) {
    Column(modifier) {
        FocusBox(
            onClick = onClick,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f),
            focusedScale = 1.08f,
            background = Surf2
        ) {
            Poster(item, Modifier.fillMaxSize(), fit = true)
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Danger)
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text("مباشر", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, color = Color(0xFFE0E0EE))
    }
}

@Composable
fun ContentCard(item: ContentItem, progress: Float, onClick: () -> Unit, modifier: Modifier? = null) {
    if (item.type == ContentType.CHANNEL) {
        if (modifier != null) ChannelCard(item, onClick, modifier) else ChannelCard(item, onClick)
    } else {
        if (modifier != null) PosterCard(item, progress, onClick, modifier) else PosterCard(item, progress, onClick)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        color = Color.White,
        modifier = modifier.padding(vertical = 8.dp)
    )
}

@Composable
fun ScreenHeader(title: String, subtitle: String = "") {
    Column(Modifier.padding(bottom = 12.dp)) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White)
        if (subtitle.isNotBlank()) Text(subtitle, fontSize = 15.sp, color = TextDim)
    }
}

@Composable
fun Field(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    multiline: Boolean = false,
    password: Boolean = false,
    number: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier,
        label = { Text(label) },
        singleLine = !multiline,
        minLines = if (multiline) 3 else 1,
        maxLines = if (multiline) 8 else 1,
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            keyboardType = when {
                number && password -> KeyboardType.NumberPassword
                number -> KeyboardType.Number
                password -> KeyboardType.Password
                multiline -> KeyboardType.Text
                else -> KeyboardType.Uri
            }
        ),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Accent,
            unfocusedBorderColor = Surf2,
            focusedLabelColor = Accent,
            unfocusedLabelColor = TextDim,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            cursorColor = Accent,
            focusedContainerColor = Surf,
            unfocusedContainerColor = Surf
        )
    )
}

@Composable
fun EmptyState(title: String, subtitle: String, action: String? = null, onAction: () -> Unit = {}) {
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.LiveTv, contentDescription = null, tint = Accent, modifier = Modifier.size(80.dp))
        Spacer(Modifier.height(16.dp))
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(6.dp))
        Text(subtitle, fontSize = 16.sp, color = TextDim, textAlign = TextAlign.Center)
        if (action != null) {
            Spacer(Modifier.height(24.dp))
            TvButton(action, onAction, primary = true)
        }
    }
}

/** قفل بالرمز السري */
@Composable
fun PinGate(pin: String, onUnlock: () -> Unit) {
    var entry by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.Lock, contentDescription = null, tint = Accent, modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(12.dp))
        Text("هذا القسم مقفل", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(16.dp))
        Field(entry, { entry = it; wrong = false }, "الرمز السري", Modifier.width(320.dp), password = true, number = true)
        Spacer(Modifier.height(12.dp))
        TvButton("فتح", { if (entry == pin) onUnlock() else wrong = true }, primary = true)
        if (wrong) {
            Spacer(Modifier.height(8.dp))
            Text("الرمز غلط", color = Danger)
        }
    }
}

fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
