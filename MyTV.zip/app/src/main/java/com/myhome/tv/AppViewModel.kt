package com.myhome.tv

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.myhome.tv.data.AppSettings
import com.myhome.tv.data.Assistant
import com.myhome.tv.data.ChatMessage
import com.myhome.tv.data.ContentItem
import com.myhome.tv.data.ContentType
import com.myhome.tv.data.Episode
import com.myhome.tv.data.Http
import com.myhome.tv.data.M3uParser
import com.myhome.tv.data.Progress
import com.myhome.tv.data.Storage
import com.myhome.tv.data.Tmdb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

/** عقل التطبيق: المكتبة، الإعدادات، مكان التوقف، والمساعد الذكي */
class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Storage(app)
    private val saveDispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()

    val items = mutableStateListOf<ContentItem>()
    private val progress = mutableStateMapOf<String, Progress>()

    var settings by mutableStateOf(store.loadSettings())
        private set
    var adminUnlocked by mutableStateOf(false)

    val chat = mutableStateListOf<ChatMessage>()
    var aiBusy by mutableStateOf(false)
        private set

    init {
        items.addAll(store.loadLibrary())
        reloadProgress()
    }

    // ---------- المكتبة ----------
    fun item(id: String?): ContentItem? = id?.let { wanted -> items.firstOrNull { it.id == wanted } }

    fun upsert(item: ContentItem) {
        val i = items.indexOfFirst { it.id == item.id }
        if (i >= 0) items[i] = item else items.add(0, item)
        persist()
    }

    fun delete(id: String) {
        items.removeAll { it.id == id }
        persist()
    }

    private fun persist() {
        val snapshot = items.toList()
        viewModelScope.launch(saveDispatcher) { store.saveLibrary(snapshot) }
    }

    /** استيراد قنوات من رابط ملف M3U أو من نص ملصوق. يرجّع عدد القنوات المضافة. */
    suspend fun importM3u(source: String, isUrl: Boolean, category: String): Int {
        val text = if (isUrl) withContext(Dispatchers.IO) { Http.get(source) } else source
        val parsed = M3uParser.parse(text).map { if (category.isNotBlank()) it.copy(category = category) else it }
        val existingUrls = items.filter { it.type == ContentType.CHANNEL }.map { it.url }.toSet()
        val fresh = parsed.filter { it.url !in existingUrls }
        items.addAll(fresh)
        persist()
        return fresh.size
    }

    suspend fun fetchMeta(title: String, type: ContentType): Tmdb.Meta? =
        withContext(Dispatchers.IO) { Tmdb.lookup(settings.tmdbKey, title, type) }

    // ---------- الإعدادات ----------
    fun updateSettings(s: AppSettings) {
        settings = s
        store.saveSettings(s)
    }

    // ---------- مكان التوقف ----------
    fun reloadProgress() {
        progress.clear()
        progress.putAll(store.loadProgress())
    }

    fun progressOf(key: String): Progress? = progress[key]

    fun movieFraction(item: ContentItem): Float {
        val p = progress[item.id] ?: return 0f
        if (p.finished || p.duration <= 0) return 0f
        return (p.position.toFloat() / p.duration).coerceIn(0f, 1f)
    }

    fun continueWatching(): List<ContentItem> =
        progress.values
            .filter { !it.finished && it.position > 0 }
            .sortedByDescending { it.updatedAt }
            .map { it.itemId }
            .distinct()
            .mapNotNull { item(it) }
            .filter { it.type != ContentType.CHANNEL }

    /** الحلقة اللي المفروض تكمل منها + مكان التوقف */
    fun resumeEpisode(item: ContentItem): Pair<Episode, Long>? {
        val eps = item.sortedEpisodes()
        if (eps.isEmpty()) return null
        val last = progress.values
            .filter { it.itemId == item.id && it.key != item.id }
            .maxByOrNull { it.updatedAt }
        val ep = last?.let { l -> eps.firstOrNull { Progress.key(item.id, it) == l.key } }
        if (last == null || ep == null) return eps.first() to 0L
        return if (last.finished) (item.nextEpisode(ep) ?: ep) to 0L else ep to last.position
    }

    // ---------- المساعد الذكي ----------
    fun askAssistant(text: String, onAction: (Assistant.Action) -> Unit) {
        val clean = text.trim()
        if (clean.isEmpty() || aiBusy) return
        chat.add(ChatMessage(true, clean))
        val s = settings
        if (s.claudeKey.isBlank()) {
            chat.add(ChatMessage(false, "عشان أشتغل، أضف مفتاح Claude API من صفحة الإعدادات 🔑"))
            return
        }
        val history = chat.toList().takeLast(12).dropWhile { !it.fromUser }
        val library = items.toList()
        val recent = continueWatching().take(5).map { it.title }
        aiBusy = true
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) { Assistant.ask(s.claudeKey, s.claudeModel, history, library, recent) }
            }
            aiBusy = false
            result.onSuccess { r ->
                chat.add(ChatMessage(false, r.text))
                r.action?.let(onAction)
            }.onFailure { e ->
                chat.add(ChatMessage(false, "صار خطأ في الاتصال: ${e.message ?: "غير معروف"}"))
            }
        }
    }

    override fun onCleared() {
        saveDispatcher.close()
        super.onCleared()
    }
}
