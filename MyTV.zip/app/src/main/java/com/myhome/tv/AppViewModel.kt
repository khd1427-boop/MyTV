package com.myhome.tv

import android.app.Application
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.myhome.tv.data.AppSettings
import com.myhome.tv.data.Assistant
import com.myhome.tv.data.ChatMessage
import com.myhome.tv.data.ContentItem
import com.myhome.tv.data.ContentType
import com.myhome.tv.data.Episode
import com.myhome.tv.data.Http
import com.myhome.tv.data.LinkInspector
import com.myhome.tv.data.M3uParser
import com.myhome.tv.data.Progress
import com.myhome.tv.data.Storage
import com.myhome.tv.data.Tmdb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.concurrent.Executors

/** عقل التطبيق: المكتبة، الإعدادات، مكان التوقف، والمساعد الذكي */
class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Storage(app)
    private val saveDispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()

    val items = mutableStateListOf<ContentItem>()
    private val progress = mutableStateMapOf<String, Progress>()

    var settings by mutableStateOf(store.loadSettings())
        private set

    /** القفل مفتوح؟ (للإدارة والإعدادات والمساعد). يتقفل تلقائياً بعد 30 دقيقة */
    var adminUnlocked by mutableStateOf(false)
        private set
    private var unlockedAt = 0L

    val chat = mutableStateListOf<ChatMessage>()
    private val memory = mutableStateListOf<String>()
    var aiBusy by mutableStateOf(false)
        private set

    /** طلب تشغيل المايك (من زر الريموت) */
    var pendingVoice by mutableStateOf(false)

    // النطق بالصوت
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        items.addAll(store.loadLibrary())
        chat.addAll(store.loadChat())
        memory.addAll(store.loadMemory())
        reloadProgress()
        tts = TextToSpeech(app) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("ar"))
                ttsReady = true
            }
        }
    }

    val hasPin: Boolean get() = settings.pin.isNotBlank()
    val isLocked: Boolean
        get() = hasPin && (!adminUnlocked || System.currentTimeMillis() - unlockedAt > AUTO_LOCK_MS)

    /** يجرّب الرمز. يرجّع null لو صح، أو رسالة الخطأ. بعد 5 محاولات غلط يقفل 5 دقائق (وتتضاعف) */
    fun tryUnlock(entry: String): String? {
        val now = System.currentTimeMillis()
        val until = store.lockedUntil()
        if (now < until) {
            val secs = (until - now) / 1000 + 1
            return "محاولات كثيرة غلط. انتظر $secs ثانية"
        }
        if (Storage.verifyPin(entry, settings.pin)) {
            store.saveAttempts(0, 0)
            adminUnlocked = true
            unlockedAt = now
            return null
        }
        val failed = store.failedAttempts() + 1
        return if (failed >= 5) {
            val rounds = failed / 5
            val lockMs = 5 * 60_000L * (1L shl (rounds - 1).coerceAtMost(6))
            store.saveAttempts(failed, now + lockMs)
            "الرمز غلط. انقفل لمدة ${lockMs / 60_000} دقيقة"
        } else {
            store.saveAttempts(failed, 0)
            "الرمز غلط (باقي ${5 - failed} محاولات)"
        }
    }

    fun lockNow() {
        adminUnlocked = false
    }

    /** تغيير الرمز (فاضي = إزالة القفل). يحتاج يكون القفل مفتوح */
    fun setPin(newPin: String) {
        if (isLocked) return
        updateSettings(settings.copy(pin = if (newPin.isBlank()) "" else Storage.hashPin(newPin)))
        if (newPin.isNotBlank()) {
            adminUnlocked = true
            unlockedAt = System.currentTimeMillis()
        }
    }
    val assistantLocked: Boolean get() = isLocked && settings.lockAssistant

    // ---------- المكتبة ----------
    fun item(id: String?): ContentItem? = id?.let { wanted -> items.firstOrNull { it.id == wanted } }

    fun upsert(item: ContentItem) {
        val i = items.indexOfFirst { it.id == item.id }
        if (i >= 0) items[i] = item else items.add(0, item)
        persist()
    }

    fun delete(id: String) {
        items.removeAll { it.id == id }
        persist()
    }

    private fun persist() {
        val snapshot = items.toList()
        viewModelScope.launch(saveDispatcher) { store.saveLibrary(snapshot) }
    }

    /** استيراد قنوات من رابط ملف M3U أو من نص ملصوق. يرجّع عدد القنوات المضافة. */
    suspend fun importM3u(source: String, isUrl: Boolean, category: String): Int {
        val text = if (isUrl) withContext(Dispatchers.IO) { Http.get(source) } else source
        val parsed = M3uParser.parse(text).map { if (category.isNotBlank()) it.copy(category = category) else it }
        val existingUrls = items.filter { it.type == ContentType.CHANNEL }.map { it.url }.toSet()
        val fresh = parsed.filter { it.url !in existingUrls }
        items.addAll(fresh)
        persist()
        return fresh.size
    }

    /**
     * إضافة ذكية: تلصق أي رابط، والتطبيق يفحصه ويعرف نوعه ويضيفه في مكانه الصح.
     * يرجّع رسالة بالعربي بالنتيجة.
     */
    suspend fun smartAdd(url: String, title: String, category: String): String {
        val clean = url.trim()
        if (clean.isBlank()) return "الصق الرابط أول"
        val r = withContext(Dispatchers.IO) { LinkInspector.inspect(clean) }
        val name = title.trim().ifBlank { r.title }
        val warn = if (r.reachable) "" else "\n⚠️ ${r.detail}"
        return when (r.kind) {
            LinkInspector.Kind.PLAYLIST -> try {
                val n = importM3u(clean, true, category.trim())
                "تم استيراد $n قناة من القائمة ✓"
            } catch (e: Exception) {
                "ما قدرت أقرأ قائمة القنوات: ${e.message}"
            }
            LinkInspector.Kind.LIVE -> {
                upsert(ContentItem(type = ContentType.CHANNEL, title = name, url = clean, category = category.trim()))
                "انضافت القناة \"$name\" ✓$warn"
            }
            LinkInspector.Kind.VIDEO -> {
                upsert(ContentItem(type = ContentType.MOVIE, title = name, url = clean, category = category.trim()))
                "انضاف الفيلم \"$name\" ✓$warn"
            }
            LinkInspector.Kind.WEBSITE -> {
                upsert(ContentItem(type = ContentType.WEBSITE, title = name, url = clean, category = category.trim()))
                "انضاف الموقع \"$name\" ✓$warn"
            }
        }
    }

    suspend fun inspectLink(url: String): LinkInspector.Result =
        withContext(Dispatchers.IO) { LinkInspector.inspect(url.trim()) }

    suspend fun fetchMeta(title: String, type: ContentType): Tmdb.Meta? =
        withContext(Dispatchers.IO) { Tmdb.lookup(settings.tmdbKey, title, type) }

    // ---------- الإعدادات ----------
    fun updateSettings(s: AppSettings) {
        if (isLocked) return
        settings = s
        store.saveSettings(s)
    }

    // ---------- مكان التوقف ----------
    fun reloadProgress() {
        progress.clear()
        progress.putAll(store.loadProgress())
    }

    fun progressOf(key: String): Progress? = progress[key]

    fun movieFraction(item: ContentItem): Float {
        val p = progress[item.id] ?: return 0f
        if (p.finished || p.duration <= 0) return 0f
        return (p.position.toFloat() / p.duration).coerceIn(0f, 1f)
    }

    fun continueWatching(): List<ContentItem> =
        progress.values
            .filter { !it.finished && it.position > 0 }
            .sortedByDescending { it.updatedAt }
            .map { it.itemId }
            .distinct()
            .mapNotNull { item(it) }
            .filter { it.type != ContentType.CHANNEL }

    /** الحلقة اللي المفروض تكمل منها + مكان التوقف */
    fun resumeEpisode(item: ContentItem): Pair<Episode, Long>? {
        val eps = item.sortedEpisodes()
        if (eps.isEmpty()) return null
        val last = progress.values
            .filter { it.itemId == item.id && it.key != item.id }
            .maxByOrNull { it.updatedAt }
        val ep = last?.let { l -> eps.firstOrNull { Progress.key(item.id, it) == l.key } }
        if (last == null || ep == null) return eps.first() to 0L
        return if (last.finished) (item.nextEpisode(ep) ?: ep) to 0L else ep to last.position
    }

    // ---------- المساعد الذكي ----------
    fun memoryList(): List<String> = memory.toList()

    fun forgetMemory() {
        memory.clear()
        store.saveMemory(emptyList())
    }

    fun clearChat() {
        chat.clear()
        store.saveChat(emptyList())
        stopSpeaking()
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    private fun speak(text: String) {
        if (!settings.voiceReply || !ttsReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "reply")
    }

    private fun addChat(m: ChatMessage) {
        chat.add(m)
        store.saveChat(chat.toList())
    }

    /**
     * يرسل طلبك للمساعد. الإجراءات اللي تخص الشاشات (تشغيل، فتح، بحث) تروح لـ onAction،
     * والإجراءات اللي تخص البيانات (إضافة، حذف، استيراد) تتنفذ هنا مباشرة.
     */
    fun askAssistant(text: String, onAction: (Assistant.Action) -> Unit) {
        val clean = text.trim()
        if (clean.isEmpty() || aiBusy) return
        if (assistantLocked) return
        stopSpeaking()
        addChat(ChatMessage(true, clean))
        val s = settings
        if (s.claudeKey.isBlank()) {
            addChat(ChatMessage(false, "يا أبو معاذ، عشان أشتغل أضف مفتاح Claude API من صفحة الإعدادات"))
            return
        }
        val history = chat.toList().takeLast(16).dropWhile { !it.fromUser }
        val library = items.toList()
        val recent = continueWatching().take(5).map { it.title }
        val mem = memory.toList()
        aiBusy = true
        viewModelScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    Assistant.ask(s.claudeKey, s.claudeModel, history, library, recent, mem, s.webSearch)
                }
            }
            aiBusy = false
            result.onSuccess { r ->
                addChat(ChatMessage(false, r.text))
                speak(r.text)
                if (r.remember.isNotBlank() && r.remember !in memory) {
                    memory.add(r.remember)
                    store.saveMemory(memory.toList())
                }
                r.actions.forEach { a -> runAction(a, onAction) }
            }.onFailure { e ->
                addChat(ChatMessage(false, "صار خطأ في الاتصال: ${e.message ?: "غير معروف"}"))
            }
        }
    }

    private fun runAction(a: Assistant.Action, onAction: (Assistant.Action) -> Unit) {
        when (a.type) {
            "add" -> {
                if (a.url.isBlank()) return
                val explicit = runCatching { ContentType.valueOf(a.contentType.uppercase()) }.getOrNull()
                if (explicit == null || a.title.isBlank()) {
                    // النوع غير محدد: التطبيق يفحص الرابط ويقرر
                    viewModelScope.launch { addChat(ChatMessage(false, smartAdd(a.url, a.title, a.category))) }
                    return
                }
                val type = explicit
                upsert(
                    ContentItem(
                        type = type,
                        title = a.title,
                        url = if (type == ContentType.SERIES) "" else a.url,
                        category = a.category,
                        episodes = if (type == ContentType.SERIES) listOf(Episode(1, 1, "", a.url)) else emptyList()
                    )
                )
            }
            "delete" -> {
                if (isLocked) {
                    addChat(ChatMessage(false, "الحذف يحتاج تفتح القفل برمزك السري أول"))
                } else {
                    delete(a.id)
                }
            }
            "import_m3u" -> {
                if (a.url.isBlank()) return
                viewModelScope.launch {
                    val msg = try {
                        val n = importM3u(a.url, true, a.category)
                        "تم استيراد $n قناة جديدة"
                    } catch (e: Exception) {
                        "ما قدرت أستورد القائمة: ${e.message}"
                    }
                    addChat(ChatMessage(false, msg))
                }
            }
            else -> onAction(a)
        }
    }

    companion object {
        private const val AUTO_LOCK_MS = 30 * 60_000L
    }

    override fun onCleared() {
        tts?.shutdown()
        saveDispatcher.close()
        super.onCleared()
    }
}
