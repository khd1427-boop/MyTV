package com.myhome.tv.data

import java.net.URLDecoder

/**
 * يفحص أي رابط ويعرف نوعه تلقائياً:
 * قائمة قنوات M3U، بث مباشر، فيلم/فيديو، أو موقع إنترنت.
 */
object LinkInspector {
    enum class Kind { PLAYLIST, LIVE, VIDEO, WEBSITE }

    data class Result(
        val kind: Kind,
        val title: String,
        /** وصف بالعربي لنتيجة الفحص */
        val detail: String,
        /** هل قدرنا نوصل للرابط؟ */
        val reachable: Boolean
    )

    private val videoExt = listOf(".mp4", ".mkv", ".avi", ".mov", ".webm", ".m4v", ".flv", ".wmv")

    fun inspect(rawUrl: String): Result {
        val url = rawUrl.trim()
        val lower = url.lowercase()
        val guess = guessFromUrl(lower)
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) {
            // روابط rtmp/rtsp وغيرها: بث مباشر
            return Result(Kind.LIVE, nameFromUrl(url), "رابط بث (${lower.substringBefore(":")})", false)
        }
        return try {
            val (type, head) = Http.peek(url)
            val t = type.lowercase()
            val kind = when {
                head.contains("#EXTM3U") && head.contains("#EXT-X-") ->
                    if (head.contains("#EXT-X-ENDLIST")) Kind.VIDEO else Kind.LIVE
                head.contains("#EXTM3U") || (head.contains("#EXTINF") && !head.contains("#EXT-X-")) -> Kind.PLAYLIST
                t.contains("mpegurl") -> Kind.LIVE
                t.contains("dash+xml") -> Kind.LIVE
                t.startsWith("video/") || t.startsWith("audio/") -> Kind.VIDEO
                t.contains("text/html") || head.contains("<html", ignoreCase = true) -> Kind.WEBSITE
                else -> guess
            }
            val title = if (kind == Kind.WEBSITE) pageTitle(head).ifBlank { nameFromUrl(url) } else nameFromUrl(url)
            val detail = when (kind) {
                Kind.PLAYLIST -> "قائمة قنوات فيها تقريباً ${Regex("#EXTINF").findAll(head).count()}+ قناة"
                Kind.LIVE -> "بث مباشر شغّال ✓"
                Kind.VIDEO -> "فيديو شغّال ✓"
                Kind.WEBSITE -> "موقع إنترنت ✓"
            }
            Result(kind, title, detail, true)
        } catch (e: Exception) {
            Result(guess, nameFromUrl(url), "ما قدرت أوصل للرابط الحين (${e.message ?: "خطأ"})، تأكد منه", false)
        }
    }

    private fun guessFromUrl(lower: String): Kind {
        val path = lower.substringBefore("?")
        return when {
            path.endsWith(".m3u") || lower.contains("type=m3u") || lower.contains("get.php") -> Kind.PLAYLIST
            path.endsWith(".m3u8") || path.endsWith(".mpd") || path.endsWith(".ts") -> Kind.LIVE
            videoExt.any { path.endsWith(it) } -> Kind.VIDEO
            else -> Kind.WEBSITE
        }
    }

    private fun pageTitle(html: String): String =
        Regex("<title[^>]*>([^<]{1,120})</title>", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)?.trim()
            ?.replace("&amp;", "&")?.replace("&quot;", "\"")?.replace("&#39;", "'") ?: ""

    fun nameFromUrl(url: String): String {
        val noQuery = url.substringBefore("?").trimEnd('/')
        val last = noQuery.substringAfterLast("/")
        val host = noQuery.substringAfter("://").substringBefore("/")
        val base = if (last.isBlank() || last == host) host.removePrefix("www.") else last.substringBeforeLast(".")
        return try {
            URLDecoder.decode(base, "UTF-8").replace('_', ' ').replace('-', ' ').trim().ifBlank { host }
        } catch (e: Exception) {
            base
        }
    }
}
