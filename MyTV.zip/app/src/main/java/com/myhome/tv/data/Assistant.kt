package com.myhome.tv.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * المساعد الذكي (Claude). يفهم طلبك ويرجّع رد + إجراء ينفذه التطبيق:
 * تشغيل، فتح تفاصيل، بحث، أو فتح قسم.
 */
object Assistant {
    data class Action(
        val type: String,
        val id: String = "",
        val query: String = "",
        val season: Int = 0,
        val episode: Int = 0
    )

    data class Reply(val text: String, val action: Action?)

    fun ask(
        apiKey: String,
        model: String,
        history: List<ChatMessage>,
        library: List<ContentItem>,
        recent: List<String>
    ): Reply {
        val lib = library.take(400).joinToString("\n") { i ->
            buildString {
                append(i.id).append(" | ").append(i.type.single).append(" | ").append(i.title)
                if (i.category.isNotBlank()) append(" | ").append(i.category)
                if (i.year.isNotBlank()) append(" | ").append(i.year)
                if (i.type == ContentType.SERIES) {
                    append(" | مواسم: ").append(i.seasons().joinToString(","))
                    append(" | عدد الحلقات: ").append(i.episodes.size)
                }
                if (i.description.isNotBlank()) append(" | ").append(i.description.take(120))
            }
        }.ifBlank { "(المكتبة فاضية)" }

        val system = """
أنت المساعد الذكي داخل تطبيق "تلفازي" على تلفاز المستخدم. تتكلم باللهجة السعودية بشكل مختصر وودود.

مكتبة المستخدم (المعرّف | النوع | الاسم | التصنيف | السنة | تفاصيل):
$lib

آخر ما شاهده: ${recent.joinToString("، ").ifBlank { "لا شيء" }}

قواعد الرد:
- رد دائماً بكائن JSON واحد فقط بدون أي نص قبله أو بعده، بهذا الشكل:
{"reply":"نص قصير للمستخدم","action":{"type":"none"}}
- أنواع action:
  play: تشغيل عنصر. الحقول: id، ومعها season و episode للمسلسلات (اختياري، بدونها يكمل من آخر حلقة).
  open: فتح صفحة تفاصيل عنصر. الحقل: id
  search: بحث داخل المكتبة. الحقل: query
  browse: فتح قسم. الحقل: query وقيمته MOVIE أو SERIES أو CHANNEL
  none: بدون إجراء (إجابة أو اقتراح فقط)
- استخدم فقط المعرّفات الموجودة في المكتبة أعلاه.
- إذا طلب شيء غير موجود، قل له إنه غير موجود واقترح عليه يضيفه من قسم "إدارة المحتوى".
- تقدر تجاوب على أسئلة عامة عن الأفلام والمسلسلات والممثلين والقصص، وتقترح من مكتبته حسب ذوقه.
""".trim()

        val msgs = JSONArray()
        history.forEach {
            msgs.put(JSONObject().put("role", if (it.fromUser) "user" else "assistant").put("content", it.text))
        }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 1024)
            .put("system", system)
            .put("messages", msgs)

        val resp = Http.postJson(
            "https://api.anthropic.com/v1/messages",
            body.toString(),
            mapOf("x-api-key" to apiKey, "anthropic-version" to "2023-06-01")
        )
        val content = JSONObject(resp).optJSONArray("content") ?: JSONArray()
        val text = (0 until content.length())
            .mapNotNull { content.optJSONObject(it) }
            .filter { it.optString("type") == "text" }
            .joinToString("") { it.optString("text") }
        return parse(text)
    }

    fun parse(raw: String): Reply {
        val s = raw.indexOf('{')
        val e = raw.lastIndexOf('}')
        if (s < 0 || e <= s) return Reply(raw.trim().ifBlank { "ما فهمت، عيد طلبك بطريقة ثانية" }, null)
        return try {
            val o = JSONObject(raw.substring(s, e + 1))
            val a = o.optJSONObject("action")
            val action = a?.let {
                Action(
                    type = it.optString("type", "none"),
                    id = it.optString("id", ""),
                    query = it.optString("query", ""),
                    season = it.optInt("season", 0),
                    episode = it.optInt("episode", 0)
                )
            }?.takeIf { it.type.isNotBlank() && it.type != "none" }
            Reply(o.optString("reply", "").ifBlank { "تم" }, action)
        } catch (ex: Exception) {
            Reply(raw.trim(), null)
        }
    }
}
