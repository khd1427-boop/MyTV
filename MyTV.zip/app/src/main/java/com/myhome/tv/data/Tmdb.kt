package com.myhome.tv.data

import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

/** جلب البوستر والوصف والتقييم تلقائياً من themoviedb.org */
object Tmdb {
    data class Meta(
        val poster: String,
        val backdrop: String,
        val description: String,
        val year: String,
        val rating: String
    )

    private const val IMG = "https://image.tmdb.org/t/p/"

    fun lookup(apiKey: String, title: String, type: ContentType): Meta? {
        val kind = if (type == ContentType.SERIES) "tv" else "movie"
        val q = URLEncoder.encode(title, "UTF-8")
        val first = search(apiKey, kind, q, "ar") ?: search(apiKey, kind, q, "en-US") ?: return null

        var overview = first.optString("overview", "")
        if (overview.isBlank()) {
            // ما فيه وصف عربي؟ نجيب الإنجليزي
            overview = search(apiKey, kind, q, "en-US")?.optString("overview", "") ?: ""
        }
        val date = first.optString("release_date", "").ifBlank { first.optString("first_air_date", "") }
        val vote = first.optDouble("vote_average", 0.0)
        return Meta(
            poster = img(first.optString("poster_path", ""), "w500"),
            backdrop = img(first.optString("backdrop_path", ""), "w1280"),
            description = overview,
            year = date.take(4),
            rating = if (vote > 0) String.format(Locale.US, "%.1f", vote) else ""
        )
    }

    private fun search(apiKey: String, kind: String, q: String, lang: String): JSONObject? {
        val url = "https://api.themoviedb.org/3/search/$kind?api_key=$apiKey&language=$lang&query=$q"
        val json = JSONObject(Http.get(url))
        return json.optJSONArray("results")?.optJSONObject(0)
    }

    private fun img(path: String, size: String): String =
        if (path.isBlank() || path == "null") "" else IMG + size + path
}
