package com.myhome.tv.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** نوع المحتوى */
enum class ContentType(val label: String, val single: String) {
    MOVIE("أفلام", "فيلم"),
    SERIES("مسلسلات", "مسلسل"),
    CHANNEL("قنوات", "قناة"),
    WEBSITE("مواقع", "موقع")
}

/** حلقة من مسلسل */
data class Episode(
    val season: Int,
    val number: Int,
    val title: String,
    val url: String,
    /** رابط ملف الترجمة (srt أو vtt) بأي لغة — التطبيق يترجمه للعربي */
    val subtitleUrl: String = ""
) {
    val code: String get() = "S${season}E${number}"
    val displayTitle: String get() = title.ifBlank { "الحلقة $number" }

    fun toJson(): JSONObject = JSONObject()
        .put("season", season)
        .put("number", number)
        .put("title", title)
        .put("url", url)
        .put("subtitleUrl", subtitleUrl)

    companion object {
        fun fromJson(o: JSONObject) = Episode(
            season = o.optInt("season", 1),
            number = o.optInt("number", 1),
            title = o.optString("title", ""),
            url = o.optString("url", ""),
            subtitleUrl = o.optString("subtitleUrl", "")
        )
    }
}

/** أي عنصر في المكتبة: فيلم أو مسلسل أو قناة */
data class ContentItem(
    val id: String = UUID.randomUUID().toString(),
    val type: ContentType,
    val title: String,
    val url: String = "",
    val poster: String = "",
    val backdrop: String = "",
    val description: String = "",
    val category: String = "",
    val year: String = "",
    val rating: String = "",
    /** رابط ملف الترجمة للفيلم (srt أو vtt) */
    val subtitleUrl: String = "",
    val episodes: List<Episode> = emptyList(),
    val addedAt: Long = System.currentTimeMillis()
) {
    fun sortedEpisodes(): List<Episode> =
        episodes.sortedWith(compareBy<Episode>({ it.season }, { it.number }))

    fun seasons(): List<Int> = episodes.map { it.season }.distinct().sorted()

    fun nextEpisode(current: Episode): Episode? {
        val list = sortedEpisodes()
        val i = list.indexOfFirst { it.season == current.season && it.number == current.number }
        return if (i >= 0 && i + 1 < list.size) list[i + 1] else null
    }

    fun toJson(): JSONObject {
        val eps = JSONArray()
        episodes.forEach { eps.put(it.toJson()) }
        return JSONObject()
            .put("id", id)
            .put("type", type.name)
            .put("title", title)
            .put("url", url)
            .put("poster", poster)
            .put("backdrop", backdrop)
            .put("description", description)
            .put("category", category)
            .put("year", year)
            .put("rating", rating)
            .put("subtitleUrl", subtitleUrl)
            .put("episodes", eps)
            .put("addedAt", addedAt)
    }

    companion object {
        fun fromJson(o: JSONObject): ContentItem {
            val eps = o.optJSONArray("episodes")
            val episodes = if (eps == null) emptyList() else
                (0 until eps.length()).mapNotNull { eps.optJSONObject(it)?.let(Episode::fromJson) }
            return ContentItem(
                id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
                type = runCatching { ContentType.valueOf(o.optString("type")) }.getOrDefault(ContentType.MOVIE),
                title = o.optString("title", ""),
                url = o.optString("url", ""),
                poster = o.optString("poster", ""),
                backdrop = o.optString("backdrop", ""),
                description = o.optString("description", ""),
                category = o.optString("category", ""),
                year = o.optString("year", ""),
                rating = o.optString("rating", ""),
                subtitleUrl = o.optString("subtitleUrl", ""),
                episodes = episodes,
                addedAt = o.optLong("addedAt", System.currentTimeMillis())
            )
        }
    }
}

/** مكان التوقف في فيلم أو حلقة */
data class Progress(
    val itemId: String,
    val key: String,
    val position: Long,
    val duration: Long,
    val updatedAt: Long,
    val finished: Boolean
) {
    fun toJson(): JSONObject = JSONObject()
        .put("itemId", itemId)
        .put("key", key)
        .put("position", position)
        .put("duration", duration)
        .put("updatedAt", updatedAt)
        .put("finished", finished)

    companion object {
        fun key(itemId: String, episode: Episode?): String =
            if (episode == null) itemId else "$itemId#${episode.code}"

        fun fromJson(o: JSONObject) = Progress(
            itemId = o.optString("itemId"),
            key = o.optString("key"),
            position = o.optLong("position"),
            duration = o.optLong("duration"),
            updatedAt = o.optLong("updatedAt"),
            finished = o.optBoolean("finished")
        )
    }
}

/** الإعدادات اللي تتحكم فيها من شاشة الإعدادات */
data class AppSettings(
    /** بصمة الرمز السري (مو الرمز نفسه) */
    val pin: String = "",
    /** مزوّد الذكاء الاصطناعي: gemini (مجاني) أو claude */
    val aiProvider: String = "gemini",
    val claudeKey: String = "",
    val claudeModel: String = DEFAULT_MODEL,
    val geminiKey: String = "",
    val geminiModel: String = GEMINI_MODEL,
    val tmdbKey: String = "",
    /** المساعد يبحث في الإنترنت للمعلومات الحديثة */
    val webSearch: Boolean = true,
    /** المساعد ينطق الرد بصوت */
    val voiceReply: Boolean = true,
    /** المساعد مقفل بالرمز السري، ما أحد يستخدمه غير صاحب الرمز */
    val lockAssistant: Boolean = true,
    /** ترجمة الحوار للعربي تلقائياً في المشغّل */
    val translateSubs: Boolean = true,
    /** توفير البيانات للنت الضعيف: جودة أقصاها 480p */
    val dataSaver: Boolean = false
) {
    companion object {
        const val DEFAULT_MODEL = "claude-sonnet-5-5"
        /** نموذج سريع لترجمة الحوار */
        const val FAST_MODEL = "claude-haiku-5-5"
        /** أسماء مختصرة تشير دائماً لأحدث نموذج من Google */
        const val GEMINI_MODEL = "gemini-flash-latest"
        const val GEMINI_FAST_MODEL = "gemini-flash-lite-latest"
    }
}

data class ChatMessage(val fromUser: Boolean, val text: String)
