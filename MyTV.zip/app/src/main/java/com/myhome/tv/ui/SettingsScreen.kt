package com.myhome.tv.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myhome.tv.AppViewModel
import com.myhome.tv.data.AppSettings

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s = vm.settings
    if (vm.isLocked) {
        PinGate(vm)
        return
    }
    var pin by remember { mutableStateOf("") }
    var claudeKey by remember { mutableStateOf(s.claudeKey) }
    var model by remember { mutableStateOf(s.claudeModel) }
    var tmdbKey by remember { mutableStateOf(s.tmdbKey) }
    var webSearch by remember { mutableStateOf(s.webSearch) }
    var voiceReply by remember { mutableStateOf(s.voiceReply) }
    var lockAssistant by remember { mutableStateOf(s.lockAssistant) }
    var translateSubs by remember { mutableStateOf(s.translateSubs) }
    var dataSaver by remember { mutableStateOf(s.dataSaver) }
    var saved by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenHeader("الإعدادات", "كل شيء محفوظ على جهازك فقط") }

        item { SectionTitle("القفل") }
        item {
            Text(
                if (vm.hasPin) "القفل شغّال 🔒 (يتقفل تلقائياً بعد 30 دقيقة)" else "ما فيه رمز سري، أي أحد يقدر يدخل ⚠️",
                color = if (vm.hasPin) Accent2 else Danger, fontSize = 16.sp
            )
        }
        item { Field(pin, { pin = it.filter { c -> c.isDigit() }.take(8); saved = false }, if (vm.hasPin) "رمز جديد (اتركه فاضي إذا ما تبغى تغيّره)" else "حط رمز سري (4 إلى 8 أرقام)", password = true, number = true) }
        item { Text("ننصحك تحط رمز، عشان ما أحد غيرك يتحكم في المساعد أو يغيّر المحتوى.", color = TextDim, fontSize = 14.sp) }

        item { SectionTitle("المساعد الذكي") }
        item { Field(claudeKey, { claudeKey = it; saved = false }, "مفتاح Claude API", password = true) }
        item { Field(model, { model = it; saved = false }, "اسم النموذج") }
        item { Text("المفتاح من موقع console.anthropic.com ← API Keys. المفتاح محفوظ في هذا التلفاز فقط.", color = TextDim, fontSize = 14.sp) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TvButton(if (webSearch) "البحث في الإنترنت: شغّال" else "البحث في الإنترنت: مطفي", { webSearch = !webSearch; saved = false }, primary = webSearch)
                TvButton(if (voiceReply) "الرد بالصوت: شغّال" else "الرد بالصوت: مطفي", { voiceReply = !voiceReply; saved = false }, primary = voiceReply)
                TvButton(if (lockAssistant) "قفل المساعد بالرمز: شغّال" else "قفل المساعد بالرمز: مطفي", { lockAssistant = !lockAssistant; saved = false }, primary = lockAssistant)
            }
        }
        item {
            val mem = vm.memoryList()
            Text(
                if (mem.isEmpty()) "المساعد ما حفظ أي معلومة عنك بعد"
                else "المساعد يتذكر عنك: " + mem.joinToString(" • "),
                color = TextDim, fontSize = 14.sp
            )
        }
        item { TvButton("امسح ذاكرة المساعد", { vm.forgetMemory() }) }

        item { SectionTitle("المشاهدة") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TvButton(if (translateSubs) "ترجمة الحوار للعربي: شغّالة" else "ترجمة الحوار للعربي: مطفية", { translateSubs = !translateSubs; saved = false }, primary = translateSubs)
                TvButton(if (dataSaver) "توفير البيانات (نت ضعيف): شغّال" else "توفير البيانات (نت ضعيف): مطفي", { dataSaver = !dataSaver; saved = false }, primary = dataSaver)
            }
        }
        item { Text("الترجمة تشتغل إذا للفيلم ملف ترجمة بأي لغة، أو إذا البث فيه ترجمة. توفير البيانات يخلي الجودة أقل عشان ما يقطّع.", color = TextDim, fontSize = 14.sp) }

        item { SectionTitle("جلب بيانات الأفلام تلقائياً") }
        item { Field(tmdbKey, { tmdbKey = it; saved = false }, "مفتاح TMDB API", password = true) }
        item { Text("مجاني من موقع themoviedb.org ← Settings ← API (انسخ API Key)", color = TextDim, fontSize = 14.sp) }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TvButton("حفظ", {
                    if (pin.isNotEmpty() && pin.length < 4) {
                        saved = false
                        return@TvButton
                    }
                    if (pin.isNotEmpty()) vm.setPin(pin)
                    pin = ""
                    vm.updateSettings(
                        AppSettings(
                            pin = vm.settings.pin,
                            claudeKey = claudeKey.trim(),
                            claudeModel = model.trim().ifBlank { AppSettings.DEFAULT_MODEL },
                            tmdbKey = tmdbKey.trim(),
                            webSearch = webSearch,
                            voiceReply = voiceReply,
                            lockAssistant = lockAssistant,
                            translateSubs = translateSubs,
                            dataSaver = dataSaver
                        )
                    )
                    saved = true
                }, icon = Icons.Filled.Save, primary = true)
                if (vm.hasPin) {
                    TvButton("قفل الآن", { vm.lockNow() }, icon = Icons.Filled.Lock)
                    TvButton("إزالة الرمز", { vm.setPin("") })
                }
            }
        }
        if (saved) item { Text("تم الحفظ ✓", color = Accent2, fontSize = 16.sp) }
    }
}
