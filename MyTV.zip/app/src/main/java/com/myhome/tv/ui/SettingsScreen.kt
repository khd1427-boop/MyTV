package com.myhome.tv.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myhome.tv.AppViewModel
import com.myhome.tv.data.AppSettings

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s = vm.settings
    if (s.pin.isNotBlank() && !vm.adminUnlocked) {
        PinGate(s.pin) { vm.adminUnlocked = true }
        return
    }
    var pin by remember { mutableStateOf(s.pin) }
    var claudeKey by remember { mutableStateOf(s.claudeKey) }
    var model by remember { mutableStateOf(s.claudeModel) }
    var tmdbKey by remember { mutableStateOf(s.tmdbKey) }
    var saved by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenHeader("الإعدادات", "كل شيء محفوظ على جهازك فقط") }

        item { SectionTitle("القفل") }
        item { Field(pin, { pin = it; saved = false }, "الرمز السري لإدارة المحتوى والإعدادات (فاضي = بدون قفل)", password = true, number = true) }

        item { SectionTitle("المساعد الذكي") }
        item { Field(claudeKey, { claudeKey = it; saved = false }, "مفتاح Claude API", password = true) }
        item { Field(model, { model = it; saved = false }, "اسم النموذج") }
        item { Text("المفتاح من موقع console.anthropic.com ← API Keys", color = TextDim, fontSize = 14.sp) }

        item { SectionTitle("جلب بيانات الأفلام تلقائياً") }
        item { Field(tmdbKey, { tmdbKey = it; saved = false }, "مفتاح TMDB API", password = true) }
        item { Text("مجاني من موقع themoviedb.org ← Settings ← API (انسخ API Key)", color = TextDim, fontSize = 14.sp) }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TvButton("حفظ", {
                    vm.updateSettings(
                        AppSettings(
                            pin = pin.trim(),
                            claudeKey = claudeKey.trim(),
                            claudeModel = model.trim().ifBlank { AppSettings.DEFAULT_MODEL },
                            tmdbKey = tmdbKey.trim()
                        )
                    )
                    saved = true
                }, icon = Icons.Filled.Save, primary = true)
                if (s.pin.isNotBlank()) {
                    TvButton("قفل الآن", { vm.adminUnlocked = false }, icon = Icons.Filled.Lock)
                }
            }
        }
        if (saved) item { Text("تم الحفظ ✓", color = Accent2, fontSize = 16.sp) }
    }
}
