package com.myhome.tv.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import java.security.MessageDigest
import java.security.SecureRandom
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * حفظ كل شيء على جهاز التلفاز نفسه:
 * - المكتبة في ملف library.json
 * - الإعدادات ومكان التوقف في SharedPreferences
 */
class Storage(context: Context) {
    private val appContext = context.applicationContext
    private val libFile = File(appContext.filesDir, "library.json")
    private val prefs = appContext.getSharedPreferences("mytv", Context.MODE_PRIVATE)

    /** الإعدادات الحساسة (المفاتيح والرمز السري) مشفّرة بمفتاح محفوظ في عتاد الجهاز */
    private val secure: SharedPreferences = try {
        EncryptedSharedPreferences.create(
            "mytv_secure",
            MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),
            appContext,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        appContext.getSharedPreferences("mytv_secure_fallback", Context.MODE_PRIVATE)
    }

    // ---------- المكتبة ----------
    fun loadLibrary(): List<ContentItem> = synchronized(LOCK) {
        try {
            if (!libFile.exists()) return emptyList()
            val arr = JSONArray(libFile.readText())
            (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(ContentItem::fromJson) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveLibrary(items: List<ContentItem>) {
        synchronized(LOCK) {
            val arr = JSONArray()
            items.forEach { arr.put(it.toJson()) }
            val tmp = File(appContext.filesDir, "library.json.tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(libFile)) {
                libFile.writeText(arr.toString())
                tmp.delete()
            }
        }
    }

    // ---------- مكان التوقف ----------
    fun loadProgress(): Map<String, Progress> = synchronized(LOCK) {
        try {
            val o = JSONObject(prefs.getString("progress", "{}") ?: "{}")
            o.keys().asSequence()
                .mapNotNull { k -> o.optJSONObject(k)?.let { k to Progress.fromJson(it) } }
                .toMap()
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun saveProgressEntry(p: Progress) {
        synchronized(LOCK) {
            val map = loadProgress().toMutableMap()
            map[p.key] = p
            val o = JSONObject()
            map.values.sortedByDescending { it.updatedAt }.take(500).forEach { o.put(it.key, it.toJson()) }
            prefs.edit().putString("progress", o.toString()).apply()
        }
    }

    // ---------- الإعدادات ----------
    fun loadSettings() = AppSettings(
        pin = secure.getString("pinHash", "") ?: "",
        aiProvider = prefs.getString("aiProvider", "gemini") ?: "gemini",
        claudeKey = secure.getString("claudeKey", "") ?: "",
        claudeModel = prefs.getString("claudeModel", AppSettings.DEFAULT_MODEL) ?: AppSettings.DEFAULT_MODEL,
        geminiKey = secure.getString("geminiKey", "") ?: "",
        geminiModel = prefs.getString("geminiModel", AppSettings.GEMINI_MODEL) ?: AppSettings.GEMINI_MODEL,
        tmdbKey = secure.getString("tmdbKey", "") ?: "",
        webSearch = prefs.getBoolean("webSearch", true),
        voiceReply = prefs.getBoolean("voiceReply", true),
        lockAssistant = prefs.getBoolean("lockAssistant", true),
        translateSubs = prefs.getBoolean("translateSubs", true),
        dataSaver = prefs.getBoolean("dataSaver", false)
    )

    fun saveSettings(s: AppSettings) {
        secure.edit()
            .putString("pinHash", s.pin)
            .putString("claudeKey", s.claudeKey)
            .putString("geminiKey", s.geminiKey)
            .putString("tmdbKey", s.tmdbKey)
            .apply()
        prefs.edit()
            .putString("claudeModel", s.claudeModel)
            .putString("geminiModel", s.geminiModel)
            .putString("aiProvider", s.aiProvider)
            .putBoolean("webSearch", s.webSearch)
            .putBoolean("voiceReply", s.voiceReply)
            .putBoolean("lockAssistant", s.lockAssistant)
            .putBoolean("translateSubs", s.translateSubs)
            .putBoolean("dataSaver", s.dataSaver)
            .apply()
    }

    // ---------- ذاكرة المساعد (معلومات عن أبو معاذ) ----------
    fun loadMemory(): List<String> = try {
        val arr = JSONArray(prefs.getString("memory", "[]") ?: "[]")
        (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveMemory(list: List<String>) {
        val arr = JSONArray()
        list.takeLast(60).forEach { arr.put(it) }
        prefs.edit().putString("memory", arr.toString()).apply()
    }

    // ---------- سجل المحادثة ----------
    fun loadChat(): List<ChatMessage> = try {
        val arr = JSONArray(prefs.getString("chat", "[]") ?: "[]")
        (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let { ChatMessage(it.optBoolean("u"), it.optString("t")) }
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveChat(list: List<ChatMessage>) {
        val arr = JSONArray()
        list.takeLast(40).forEach { arr.put(JSONObject().put("u", it.fromUser).put("t", it.text)) }
        prefs.edit().putString("chat", arr.toString()).apply()
    }

    // ---------- محاولات الرمز الخاطئة (محفوظة حتى لو انقفل التطبيق) ----------
    fun failedAttempts(): Int = secure.getInt("failed", 0)
    fun lockedUntil(): Long = secure.getLong("lockedUntil", 0L)
    fun saveAttempts(failed: Int, lockedUntil: Long) {
        secure.edit().putInt("failed", failed).putLong("lockedUntil", lockedUntil).apply()
    }

    companion object {
        private val LOCK = Any()

        /** الرمز ما يتخزّن أبداً، نخزّن بصمته (SHA-256 مع ملح عشوائي) */
        fun hashPin(pin: String, salt: String = randomSalt()): String {
            val md = MessageDigest.getInstance("SHA-256")
            val bytes = md.digest((salt + ":" + pin).toByteArray(Charsets.UTF_8))
            return salt + ":" + bytes.joinToString("") { "%02x".format(it) }
        }

        fun verifyPin(pin: String, stored: String): Boolean {
            val salt = stored.substringBefore(":", "")
            if (salt.isEmpty()) return false
            return MessageDigest.isEqual(hashPin(pin, salt).toByteArray(), stored.toByteArray())
        }

        private fun randomSalt(): String {
            val b = ByteArray(16)
            SecureRandom().nextBytes(b)
            return b.joinToString("") { "%02x".format(it) }
        }
    }
}
