package com.myhome.tv.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * حفظ كل شيء على جهاز التلفاز نفسه:
 * - المكتبة في ملف library.json
 * - الإعدادات ومكان التوقف في SharedPreferences
 */
class Storage(context: Context) {
    private val appContext = context.applicationContext
    private val libFile = File(appContext.filesDir, "library.json")
    private val prefs = appContext.getSharedPreferences("mytv", Context.MODE_PRIVATE)

    // ---------- المكتبة ----------
    fun loadLibrary(): List<ContentItem> = synchronized(LOCK) {
        try {
            if (!libFile.exists()) return emptyList()
            val arr = JSONArray(libFile.readText())
            (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(ContentItem::fromJson) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveLibrary(items: List<ContentItem>) {
        synchronized(LOCK) {
            val arr = JSONArray()
            items.forEach { arr.put(it.toJson()) }
            val tmp = File(appContext.filesDir, "library.json.tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(libFile)) {
                libFile.writeText(arr.toString())
                tmp.delete()
            }
        }
    }

    // ---------- مكان التوقف ----------
    fun loadProgress(): Map<String, Progress> = synchronized(LOCK) {
        try {
            val o = JSONObject(prefs.getString("progress", "{}") ?: "{}")
            o.keys().asSequence()
                .mapNotNull { k -> o.optJSONObject(k)?.let { k to Progress.fromJson(it) } }
                .toMap()
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun saveProgressEntry(p: Progress) {
        synchronized(LOCK) {
            val map = loadProgress().toMutableMap()
            map[p.key] = p
            val o = JSONObject()
            map.values.sortedByDescending { it.updatedAt }.take(500).forEach { o.put(it.key, it.toJson()) }
            prefs.edit().putString("progress", o.toString()).apply()
        }
    }

    // ---------- الإعدادات ----------
    fun loadSettings() = AppSettings(
        pin = prefs.getString("pin", "") ?: "",
        claudeKey = prefs.getString("claudeKey", "") ?: "",
        claudeModel = prefs.getString("claudeModel", AppSettings.DEFAULT_MODEL) ?: AppSettings.DEFAULT_MODEL,
        tmdbKey = prefs.getString("tmdbKey", "") ?: ""
    )

    fun saveSettings(s: AppSettings) {
        prefs.edit()
            .putString("pin", s.pin)
            .putString("claudeKey", s.claudeKey)
            .putString("claudeModel", s.claudeModel)
            .putString("tmdbKey", s.tmdbKey)
            .apply()
    }

    companion object {
        private val LOCK = Any()
    }
}
