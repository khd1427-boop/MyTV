package com.myhome.tv.player

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.myhome.tv.data.ContentItem
import com.myhome.tv.data.ContentType
import com.myhome.tv.data.Episode
import com.myhome.tv.data.Progress
import com.myhome.tv.data.Storage

/**
 * شاشة التشغيل:
 * - تكمّل من مكان التوقف وتحفظه كل 10 ثواني
 * - تشغّل الحلقة اللي بعدها تلقائياً
 * - في القنوات: زر فوق/تحت (أو CH+/CH-) يقلّب بين القنوات
 */
@OptIn(UnstableApi::class)
class PlayerActivity : ComponentActivity() {

    companion object {
        private const val EXTRA_ID = "id"
        private const val EXTRA_SEASON = "season"
        private const val EXTRA_EPISODE = "episode"
        private const val EXTRA_START = "start"

        fun intent(context: Context, itemId: String, season: Int = 0, episode: Int = 0, startAt: Long = -1): Intent =
            Intent(context, PlayerActivity::class.java)
                .putExtra(EXTRA_ID, itemId)
                .putExtra(EXTRA_SEASON, season)
                .putExtra(EXTRA_EPISODE, episode)
                .putExtra(EXTRA_START, startAt)
    }

    private lateinit var store: Storage
    private lateinit var playerView: PlayerView
    private lateinit var infoText: TextView
    private var player: ExoPlayer? = null

    private var item: ContentItem? = null
    private var episode: Episode? = null
    private var pendingStart: Long = -1
    private var channels: List<ContentItem> = emptyList()

    private val handler = Handler(Looper.getMainLooper())
    private val saver = object : Runnable {
        override fun run() {
            saveProgress(false)
            handler.postDelayed(this, 10_000)
        }
    }
    private val hideInfo = Runnable { infoText.visibility = View.GONE }

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED && !isLive()) onEnded()
        }

        override fun onPlayerError(error: PlaybackException) {
            showInfo("تعذّر تشغيل المحتوى\nتأكد إن الرابط شغّال (${error.errorCodeName})", 10_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Storage(this)
        val library = store.loadLibrary()
        val found = library.firstOrNull { it.id == intent.getStringExtra(EXTRA_ID) }
        if (found == null) {
            finish()
            return
        }
        item = found
        channels = library.filter { it.type == ContentType.CHANNEL }.sortedByDescending { it.addedAt }
        if (found.type == ContentType.SERIES) {
            val s = intent.getIntExtra(EXTRA_SEASON, 0)
            val e = intent.getIntExtra(EXTRA_EPISODE, 0)
            episode = found.episodes.firstOrNull { it.season == s && it.number == e } ?: found.sortedEpisodes().firstOrNull()
        }
        pendingStart = intent.getLongExtra(EXTRA_START, -1L)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            controllerShowTimeoutMs = 4000
        }
        root.addView(
            playerView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        infoText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 22f
            setPadding(40, 24, 40, 24)
            setBackgroundColor(0xB3000000.toInt())
            visibility = View.GONE
        }
        root.addView(
            infoText,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            ).apply { setMargins(48, 48, 48, 48) }
        )
        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        if (item != null) {
            initPlayer()
            handler.postDelayed(saver, 10_000)
        }
    }

    override fun onStop() {
        handler.removeCallbacks(saver)
        saveProgress(false)
        releasePlayer()
        super.onStop()
    }

    private fun initPlayer() {
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent("Mozilla/5.0 (Linux; Android TV) MyTV/1.0")
        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .build()
        p.addListener(listener)
        player = p
        playerView.player = p
        loadCurrent()
        playerView.requestFocus()
    }

    private fun releasePlayer() {
        player?.let {
            it.removeListener(listener)
            it.release()
        }
        player = null
        if (::playerView.isInitialized) playerView.player = null
    }

    private fun isLive() = item?.type == ContentType.CHANNEL

    private fun loadCurrent() {
        val p = player ?: return
        val cur = item ?: return
        val url = episode?.url ?: cur.url
        val mediaItem = MediaItem.Builder().setUri(url).apply {
            when {
                url.contains(".m3u8", ignoreCase = true) -> setMimeType(MimeTypes.APPLICATION_M3U8)
                url.contains(".mpd", ignoreCase = true) -> setMimeType(MimeTypes.APPLICATION_MPD)
            }
        }.build()

        var start = 0L
        if (!isLive()) {
            start = if (pendingStart >= 0) pendingStart else {
                store.loadProgress()[Progress.key(cur.id, episode)]?.let { if (it.finished) 0L else it.position } ?: 0L
            }
        }
        pendingStart = -1
        p.setMediaItem(mediaItem, start)
        p.prepare()
        p.playWhenReady = true
        showInfo(titleText(), 4000)
    }

    private fun titleText(): String {
        val cur = item ?: return ""
        val ep = episode ?: return cur.title
        return "${cur.title}\nالموسم ${ep.season} • الحلقة ${ep.number}" +
            (if (ep.title.isNotBlank()) " — ${ep.title}" else "")
    }

    private fun onEnded() {
        saveProgress(true)
        val cur = item ?: return
        val next = episode?.let { cur.nextEpisode(it) }
        if (next != null) {
            episode = next
            pendingStart = 0
            loadCurrent()
        } else {
            finish()
        }
    }

    private fun saveProgress(finished: Boolean) {
        val p = player ?: return
        val cur = item ?: return
        if (cur.type == ContentType.CHANNEL) return
        val duration = p.duration.takeIf { it > 0 } ?: 0L
        val position = p.currentPosition
        if (!finished && position < 5_000) return
        val done = finished || (duration > 0 && position >= duration * 95 / 100)
        store.saveProgressEntry(
            Progress(
                itemId = cur.id,
                key = Progress.key(cur.id, episode),
                position = if (done) 0L else position,
                duration = duration,
                updatedAt = System.currentTimeMillis(),
                finished = done
            )
        )
    }

    // تقليب القنوات بالريموت
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (isLive() && event.action == KeyEvent.ACTION_DOWN && channels.size > 1) {
            val controlsHidden = !playerView.isControllerFullyVisible
            val dir = when {
                event.keyCode == KeyEvent.KEYCODE_CHANNEL_UP -> -1
                event.keyCode == KeyEvent.KEYCODE_CHANNEL_DOWN -> 1
                controlsHidden && event.keyCode == KeyEvent.KEYCODE_DPAD_UP -> -1
                controlsHidden && event.keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> 1
                else -> 0
            }
            if (dir != 0) {
                zap(dir)
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun zap(dir: Int) {
        val idx = channels.indexOfFirst { it.id == item?.id }
        val size = channels.size
        val nextIndex = ((idx + dir) % size + size) % size
        item = channels[nextIndex]
        episode = null
        loadCurrent()
    }

    private fun showInfo(text: String, ms: Long) {
        if (!::infoText.isInitialized || text.isBlank()) return
        infoText.text = text
        infoText.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfo)
        handler.postDelayed(hideInfo, ms)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
