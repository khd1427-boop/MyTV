package com.myhome.tv.player

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import com.myhome.tv.MainActivity
import com.myhome.tv.data.AppSettings
import com.myhome.tv.data.ContentItem
import com.myhome.tv.data.ContentType
import com.myhome.tv.data.Episode
import com.myhome.tv.data.Http
import com.myhome.tv.data.Progress
import com.myhome.tv.data.Storage
import com.myhome.tv.data.Subtitles
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * شاشة التشغيل:
 * - تكمّل من مكان التوقف وتحفظه كل 10 ثواني، وتشغّل الحلقة اللي بعدها تلقائياً
 * - مهيّأة للنت الضعيف: تخزين مسبق كبير، جودة تتكيّف، وإعادة اتصال تلقائية
 * - ترجمة عربية للحوار متزامنة مع الفيلم (من ملف الترجمة أو من ترجمة البث)
 * - في القنوات: زر فوق/تحت (أو CH+/CH-) يقلّب بين القنوات
 */
@OptIn(UnstableApi::class)
class PlayerActivity : ComponentActivity() {

    companion object {
        private const val EXTRA_ID = "id"
        private const val EXTRA_SEASON = "season"
        private const val EXTRA_EPISODE = "episode"
        private const val EXTRA_START = "start"
        private const val MAX_RETRIES = 10

        fun intent(context: Context, itemId: String, season: Int = 0, episode: Int = 0, startAt: Long = -1): Intent =
            Intent(context, PlayerActivity::class.java)
                .putExtra(EXTRA_ID, itemId)
                .putExtra(EXTRA_SEASON, season)
                .putExtra(EXTRA_EPISODE, episode)
                .putExtra(EXTRA_START, startAt)
    }

    private lateinit var store: Storage
    private lateinit var settings: AppSettings
    private lateinit var playerView: PlayerView
    private lateinit var infoText: TextView
    private lateinit var subtitleOverlay: TextView
    private var player: ExoPlayer? = null

    private var item: ContentItem? = null
    private var episode: Episode? = null
    private var pendingStart: Long = -1
    private var channels: List<ContentItem> = emptyList()
    private var retries = 0

    // الترجمة
    private val worker = Executors.newSingleThreadExecutor()
    private val pendingLive = AtomicInteger(0)
    private val liveCache = HashMap<String, String>()
    private var currentCue = ""
    private var translatingUrl: String? = null

    private val handler = Handler(Looper.getMainLooper())
    private val saver = object : Runnable {
        override fun run() {
            saveProgress(false)
            handler.postDelayed(this, 10_000)
        }
    }
    private val hideInfo = Runnable { infoText.visibility = View.GONE }

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            when (playbackState) {
                Player.STATE_READY -> retries = 0
                Player.STATE_BUFFERING -> if (retries > 0) showInfo("النت ضعيف... جاري التحميل", 3000)
                Player.STATE_ENDED -> if (!isLive()) onEnded()
                else -> Unit
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            val p = player ?: return
            // البث المباشر تأخر كثير: نرجع لآخر نقطة
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                p.seekToDefaultPosition()
                p.prepare()
                return
            }
            // مشاكل الشبكة: نعيد المحاولة تلقائياً
            val network = error.errorCode in 2000..2999
            if (network && retries < MAX_RETRIES) {
                retries++
                showInfo("انقطع الاتصال، أعيد المحاولة ($retries/$MAX_RETRIES)...", 4000)
                handler.postDelayed({ player?.prepare() }, (2000L * retries).coerceAtMost(10_000L))
                return
            }
            showInfo("تعذّر تشغيل المحتوى\nتأكد إن الرابط شغّال (${error.errorCodeName})", 10_000)
        }

        override fun onCues(cueGroup: CueGroup) {
            val text = cueGroup.cues.mapNotNull { it.text?.toString() }.joinToString("\n").trim()
            handleCue(text)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Storage(this)
        settings = store.loadSettings()
        val library = store.loadLibrary()
        val found = library.firstOrNull { it.id == intent.getStringExtra(EXTRA_ID) }
        if (found == null) {
            finish()
            return
        }
        item = found
        channels = library.filter { it.type == ContentType.CHANNEL }.sortedByDescending { it.addedAt }
        if (found.type == ContentType.SERIES) {
            val s = intent.getIntExtra(EXTRA_SEASON, 0)
            val e = intent.getIntExtra(EXTRA_EPISODE, 0)
            episode = found.episodes.firstOrNull { it.season == s && it.number == e } ?: found.sortedEpisodes().firstOrNull()
        }
        pendingStart = intent.getLongExtra(EXTRA_START, -1L)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            controllerShowTimeoutMs = 4000
            setShowSubtitleButton(true)
            subtitleView?.setStyle(
                CaptionStyleCompat(
                    Color.WHITE, 0x66000000, Color.TRANSPARENT,
                    CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW, Color.BLACK, null
                )
            )
            subtitleView?.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
        }
        root.addView(
            playerView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        // ترجمة البث الحيّة تظهر هنا
        subtitleOverlay = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 26f
            gravity = Gravity.CENTER
            setShadowLayer(6f, 0f, 2f, Color.BLACK)
            setBackgroundColor(0x66000000)
            setPadding(24, 8, 24, 8)
            visibility = View.GONE
        }
        root.addView(
            subtitleOverlay,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply { setMargins(80, 0, 80, 70) }
        )
        infoText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 22f
            setPadding(40, 24, 40, 24)
            setBackgroundColor(0xB3000000.toInt())
            visibility = View.GONE
        }
        root.addView(
            infoText,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            ).apply { setMargins(48, 48, 48, 48) }
        )
        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        if (item != null) {
            initPlayer()
            handler.postDelayed(saver, 10_000)
        }
    }

    override fun onStop() {
        handler.removeCallbacks(saver)
        saveProgress(false)
        releasePlayer()
        super.onStop()
    }

    private fun initPlayer() {
        // إعدادات النت الضعيف
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(20_000)
            .setReadTimeoutMs(25_000)
            .setUserAgent("Mozilla/5.0 (Linux; Android TV) MyTV/1.0")
        val mediaSourceFactory = DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http))
            .setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(8))
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                30_000,   // أقل تخزين مسبق
                120_000,  // أقصى تخزين مسبق (دقيقتين)
                2_500,    // يبدأ التشغيل بعد 2.5 ثانية
                6_000     // بعد التقطيع ينتظر 6 ثواني عشان ما يرجع يقطّع
            )
            .build()
        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .build()
        val params = p.trackSelectionParameters.buildUpon()
            .setPreferredTextLanguage("ar")
            .setPreferredAudioLanguage("ar")
        if (settings.dataSaver) params.setMaxVideoSize(854, 480)
        p.trackSelectionParameters = params.build()
        p.addListener(listener)
        player = p
        playerView.player = p
        loadCurrent()
        playerView.requestFocus()
    }

    private fun releasePlayer() {
        player?.let {
            it.removeListener(listener)
            it.release()
        }
        player = null
        if (::playerView.isInitialized) playerView.player = null
    }

    private fun isLive() = item?.type == ContentType.CHANNEL

    private fun currentSubtitleUrl(): String? {
        val ep = episode
        val raw = if (ep != null) ep.subtitleUrl else item?.subtitleUrl ?: ""
        return raw.trim().ifBlank { null }
    }

    private fun subsDir(): File = File(cacheDir, "subs").apply { mkdirs() }

    private fun loadCurrent() {
        val p = player ?: return
        val cur = item ?: return
        val url = episode?.url ?: cur.url
        val builder = MediaItem.Builder().setUri(url)
        when {
            url.contains(".m3u8", ignoreCase = true) -> builder.setMimeType(MimeTypes.APPLICATION_M3U8)
            url.contains(".mpd", ignoreCase = true) -> builder.setMimeType(MimeTypes.APPLICATION_MPD)
        }

        // ملف الترجمة: العربي الجاهز إن وجد، وإلا الأصلي (ويبدأ يترجمه)
        val subUrl = currentSubtitleUrl()
        if (subUrl != null) {
            val arabic = Subtitles.cacheFile(subsDir(), subUrl)
            val config = if (arabic.exists()) {
                MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(arabic))
                    .setMimeType(MimeTypes.APPLICATION_SUBRIP)
                    .setLanguage("ar")
                    .setLabel("العربية")
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build()
            } else {
                MediaItem.SubtitleConfiguration.Builder(Uri.parse(subUrl))
                    .setMimeType(if (subUrl.lowercase().contains(".vtt")) MimeTypes.TEXT_VTT else MimeTypes.APPLICATION_SUBRIP)
                    .setLanguage("und")
                    .setLabel("الأصلية")
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build()
            }
            builder.setSubtitleConfigurations(listOf(config))
            if (!arabic.exists()) translateSubtitleFile(subUrl, arabic)
        }

        var start = 0L
        if (!isLive()) {
            start = if (pendingStart >= 0) pendingStart else {
                store.loadProgress()[Progress.key(cur.id, episode)]?.let { if (it.finished) 0L else it.position } ?: 0L
            }
        }
        pendingStart = -1
        retries = 0
        currentCue = ""
        subtitleOverlay.visibility = View.GONE
        p.setMediaItem(builder.build(), start)
        p.prepare()
        p.playWhenReady = true
        showInfo(titleText(), 4000)
    }

    /** يترجم ملف الترجمة كامل للعربي بالخلفية، ولما يخلص يبدّله بدون ما يوقف الفيلم */
    private fun translateSubtitleFile(subUrl: String, target: File) {
        if (!settings.translateSubs || settings.claudeKey.isBlank() || translatingUrl == subUrl) return
        translatingUrl = subUrl
        val key = settings.claudeKey
        worker.execute {
            try {
                val cues = Subtitles.parse(Http.get(subUrl))
                if (cues.isEmpty()) return@execute
                val translated = Subtitles.translateCues(key, cues) { pct ->
                    runOnUiThread { showInfo("جاري ترجمة الحوار للعربي... $pct%", 4000) }
                }
                val tmp = File(target.parentFile, target.name + ".tmp")
                tmp.writeText(Subtitles.toSrt(translated))
                tmp.renameTo(target)
                runOnUiThread {
                    if (currentSubtitleUrl() == subUrl && player != null) {
                        pendingStart = player?.currentPosition ?: 0L
                        loadCurrent()
                        showInfo("الترجمة العربية جاهزة ✓", 3000)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { showInfo("ما قدرت أترجم الحوار: ${e.message}", 5000) }
            } finally {
                translatingUrl = null
            }
        }
    }

    /** ترجمة حيّة لأي ترجمة غير عربية تطلع في البث */
    private fun handleCue(text: String) {
        currentCue = text
        val canTranslate = settings.translateSubs && settings.claudeKey.isNotBlank()
        if (text.isEmpty() || !canTranslate || Subtitles.isArabic(text)) {
            subtitleOverlay.visibility = View.GONE
            playerView.subtitleView?.visibility = View.VISIBLE
            return
        }
        playerView.subtitleView?.visibility = View.INVISIBLE
        val cached = liveCache[text]
        subtitleOverlay.text = cached ?: text
        subtitleOverlay.visibility = View.VISIBLE
        if (cached != null || pendingLive.get() > 3) return
        pendingLive.incrementAndGet()
        val key = settings.claudeKey
        worker.execute {
            val tr = try {
                Subtitles.translateLines(key, listOf(text)).firstOrNull()
            } catch (e: Exception) {
                null
            }
            pendingLive.decrementAndGet()
            if (tr != null) {
                runOnUiThread {
                    liveCache[text] = tr
                    if (currentCue == text) subtitleOverlay.text = tr
                }
            }
        }
    }

    private fun titleText(): String {
        val cur = item ?: return ""
        val ep = episode ?: return cur.title
        return "${cur.title}\nالموسم ${ep.season} • الحلقة ${ep.number}" +
            (if (ep.title.isNotBlank()) " — ${ep.title}" else "")
    }

    private fun onEnded() {
        saveProgress(true)
        val cur = item ?: return
        val next = episode?.let { cur.nextEpisode(it) }
        if (next != null) {
            episode = next
            pendingStart = 0
            loadCurrent()
        } else {
            finish()
        }
    }

    private fun saveProgress(finished: Boolean) {
        val p = player ?: return
        val cur = item ?: return
        if (cur.type == ContentType.CHANNEL) return
        val duration = p.duration.takeIf { it > 0 } ?: 0L
        val position = p.currentPosition
        if (!finished && position < 5_000) return
        val done = finished || (duration > 0 && position >= duration * 95 / 100)
        store.saveProgressEntry(
            Progress(
                itemId = cur.id,
                key = Progress.key(cur.id, episode),
                position = if (done) 0L else position,
                duration = duration,
                updatedAt = System.currentTimeMillis(),
                finished = done
            )
        )
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // زر المايك في الريموت أثناء المشاهدة: يفتح المساعد
        if (event.action == KeyEvent.ACTION_DOWN && MainActivity.isVoiceKey(event.keyCode)) {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .putExtra(MainActivity.EXTRA_VOICE, true)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
            finish()
            return true
        }
        // تقليب القنوات بالريموت
        if (isLive() && event.action == KeyEvent.ACTION_DOWN && channels.size > 1) {
            val controlsHidden = !playerView.isControllerFullyVisible
            val dir = when {
                event.keyCode == KeyEvent.KEYCODE_CHANNEL_UP -> -1
                event.keyCode == KeyEvent.KEYCODE_CHANNEL_DOWN -> 1
                controlsHidden && event.keyCode == KeyEvent.KEYCODE_DPAD_UP -> -1
                controlsHidden && event.keyCode == KeyEvent.KEYCODE_DPAD_DOWN -> 1
                else -> 0
            }
            if (dir != 0) {
                zap(dir)
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun zap(dir: Int) {
        val idx = channels.indexOfFirst { it.id == item?.id }
        val size = channels.size
        val nextIndex = ((idx + dir) % size + size) % size
        item = channels[nextIndex]
        episode = null
        loadCurrent()
    }

    private fun showInfo(text: String, ms: Long) {
        if (!::infoText.isInitialized || text.isBlank()) return
        infoText.text = text
        infoText.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfo)
        handler.postDelayed(hideInfo, ms)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        worker.shutdownNow()
        super.onDestroy()
    }
}
