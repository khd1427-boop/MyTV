package com.myhome.tv.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.myhome.tv.AppViewModel
import com.myhome.tv.data.ContentItem

@Composable
fun SearchScreen(vm: AppViewModel, initial: String, onOpen: (ContentItem) -> Unit) {
    var query by remember(initial) { mutableStateOf(initial) }
    val q = query.trim()
    val results = if (q.isEmpty()) emptyList() else vm.items.filter {
        it.title.contains(q, ignoreCase = true) ||
            it.category.contains(q, ignoreCase = true) ||
            it.description.contains(q, ignoreCase = true) ||
            it.year == q
    }

    Column(Modifier.fillMaxSize().padding(32.dp)) {
        ScreenHeader("بحث", "ابحث بالاسم أو التصنيف أو السنة")
        Field(query, { query = it }, "اكتب هنا...")
        Spacer(Modifier.height(16.dp))
        when {
            q.isEmpty() -> Text("اكتب كلمة للبحث، أو اطلب من المساعد الذكي يدوّر لك", color = TextDim)
            results.isEmpty() -> Text("ما لقيت شيء باسم \"$q\"", color = TextDim)
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(170.dp),
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(18.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                items(results, key = { it.id }) { item ->
                    ContentCard(item, vm.movieFraction(item), onClick = { onOpen(item) }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}
