package com.myhome.tv.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// ألوان التطبيق — غيّرها من هنا وتتغير في كل مكان
val Accent = Color(0xFF8B5CF6)   // بنفسجي
val Accent2 = Color(0xFFEC4899)  // وردي
val Gold = Color(0xFFF5C451)     // ذهبي
val Bg = Color(0xFF07070D)
val Surf = Color(0xFF12121C)
val Surf2 = Color(0xFF1E1E2E)
val TextDim = Color(0xFFA1A1B5)
val Danger = Color(0xFFFF4D6D)

/** التدرّج اللوني الرئيسي (للأزرار والشعار) */
val AccentBrush = Brush.horizontalGradient(listOf(Accent, Accent2))

@Composable
fun MyTvTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            secondary = Accent2,
            background = Bg,
            surface = Surf,
            onPrimary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}
