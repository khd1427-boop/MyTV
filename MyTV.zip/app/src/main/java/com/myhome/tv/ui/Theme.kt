package com.myhome.tv.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ألوان التطبيق — غيّرها من هنا وتتغير في كل مكان
val Accent = Color(0xFF7C5CFF)
val Accent2 = Color(0xFF00D1FF)
val Bg = Color(0xFF0A0A12)
val Surf = Color(0xFF14141F)
val Surf2 = Color(0xFF23233A)
val TextDim = Color(0xFFA8A8C0)
val Danger = Color(0xFFFF5470)

@Composable
fun MyTvTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            secondary = Accent2,
            background = Bg,
            surface = Surf,
            onPrimary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}
