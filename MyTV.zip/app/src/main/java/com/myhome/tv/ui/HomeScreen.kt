package com.myhome.tv.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.myhome.tv.AppViewModel
import com.myhome.tv.Tab
import com.myhome.tv.data.ContentItem
import com.myhome.tv.data.ContentType
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun HomeScreen(
    vm: AppViewModel,
    tab: Tab,
    onOpen: (ContentItem) -> Unit,
    onPlay: (ContentItem) -> Unit,
    onAdd: () -> Unit
) {
    val all = vm.items.sortedByDescending { it.addedAt }
    val list = when (tab) {
        Tab.HOME -> all
        Tab.MOVIES -> all.filter { it.type == ContentType.MOVIE }
        Tab.SERIES -> all.filter { it.type == ContentType.SERIES }
        Tab.CHANNELS -> all.filter { it.type == ContentType.CHANNEL }
        Tab.WEBSITES -> all.filter { it.type == ContentType.WEBSITE }
    }
    if (list.isEmpty()) {
        EmptyState(
            title = "حيّاك الله يا أبو معاذ",
            subtitle = "ما فيه محتوى هنا بعد. روح لقسم \"إدارة المحتوى\" وأضف أول فيلم أو مسلسل أو قناة",
            action = "إضافة محتوى",
            onAction = onAdd
        )
        return
    }

    // الواجهة الكبيرة فوق: تتبدّل تلقائياً، وتعرض العنصر اللي واقف عليه الريموت
    val candidates = list
        .filter {
            (it.type == ContentType.MOVIE || it.type == ContentType.SERIES) &&
                (it.backdrop.isNotBlank() || it.poster.isNotBlank())
        }
        .take(6)
        .ifEmpty { list.take(6) }
    var rotate by remember(tab) { mutableIntStateOf(0) }
    var focused by remember(tab) { mutableStateOf<ContentItem?>(null) }
    LaunchedEffect(tab) {
        while (true) {
            delay(8000)
            if (focused == null) rotate++
        }
    }
    val hero = focused ?: candidates[rotate % candidates.size]
    val continueList = if (tab == Tab.HOME) vm.continueWatching() else emptyList()
    val onFocus: (ContentItem) -> Unit = { focused = it }

    Column(Modifier.fillMaxSize()) {
        Hero(hero, onPlay = { onPlay(hero) }, onOpen = { onOpen(hero) })
        LazyColumn(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(bottom = 48.dp)
        ) {
            if (tab == Tab.HOME) {
                if (continueList.isNotEmpty()) {
                    item(key = "continue") { ContentRow("تابع المشاهدة", continueList, vm, onOpen, onFocus) }
                }
                val channels = list.filter { it.type == ContentType.CHANNEL }
                if (channels.isNotEmpty()) item(key = "channels") { ContentRow("القنوات المباشرة", channels.take(40), vm, onOpen, onFocus) }
                val movies = list.filter { it.type == ContentType.MOVIE }
                if (movies.isNotEmpty()) item(key = "movies") { ContentRow("أحدث الأفلام", movies.take(40), vm, onOpen, onFocus) }
                val series = list.filter { it.type == ContentType.SERIES }
                if (series.isNotEmpty()) item(key = "series") { ContentRow("المسلسلات", series.take(40), vm, onOpen, onFocus) }
                val sites = list.filter { it.type == ContentType.WEBSITE }
                if (sites.isNotEmpty()) item(key = "sites") { ContentRow("مواقعي", sites.take(40), vm, onOpen, onFocus) }
                val top = list.filter { (it.type == ContentType.MOVIE || it.type == ContentType.SERIES) && (it.rating.toFloatOrNull() ?: 0f) >= 7.5f }
                    .sortedByDescending { it.rating.toFloatOrNull() ?: 0f }
                if (top.size >= 3) item(key = "top") { ContentRow("الأعلى تقييماً ⭐", top.take(30), vm, onOpen, onFocus) }
                list.filter { (it.type == ContentType.MOVIE || it.type == ContentType.SERIES) && it.category.isNotBlank() }
                    .groupBy { it.category }
                    .forEach { (cat, l) -> item(key = "cat_$cat") { ContentRow(cat, l, vm, onOpen, onFocus) } }
            } else {
                list.groupBy { it.category.ifBlank { "الكل" } }
                    .forEach { (cat, l) -> item(key = "cat_$cat") { ContentRow(cat, l, vm, onOpen, onFocus) } }
            }
        }
    }
}

@Composable
fun ContentRow(
    title: String,
    list: List<ContentItem>,
    vm: AppViewModel,
    onClick: (ContentItem) -> Unit,
    onFocus: (ContentItem) -> Unit = {}
) {
    Column(Modifier.padding(top = 6.dp)) {
        Row(Modifier.padding(horizontal = 32.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .width(4.dp)
                    .height(20.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(AccentBrush)
            )
            Spacer(Modifier.width(10.dp))
            SectionTitle(title)
            Spacer(Modifier.width(8.dp))
            Text("${list.size}", color = TextDim, fontSize = 14.sp)
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 32.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            items(list, key = { it.id }) { item ->
                ContentCard(item, vm.movieFraction(item), onClick = { onClick(item) }, onFocus = { onFocus(item) })
            }
        }
    }
}

@Composable
fun Hero(item: ContentItem, onPlay: () -> Unit, onOpen: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(340.dp)
    ) {
        Crossfade(targetState = item, animationSpec = tween(700), label = "hero") { shown ->
            Box(Modifier.fillMaxSize()) {
                val img = shown.backdrop.ifBlank { shown.poster }
                if (img.isNotBlank()) {
                    AsyncImage(
                        model = img,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Accent, Accent2, Bg))))
                }
                // تظليل سينمائي عشان النص يبان
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg.copy(alpha = 0.2f), Color.Transparent, Bg))))
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Transparent, Bg.copy(alpha = 0.95f)))))

                Column(
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 32.dp, end = 32.dp, bottom = 84.dp)
                        .fillMaxWidth(0.55f)
                ) {
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(AccentBrush)
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    ) {
                        Text(shown.type.single, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(shown.title, fontSize = 42.sp, fontWeight = FontWeight.Black, color = Color.White, maxLines = 2, lineHeight = 48.sp)
                    val meta = listOf(
                        shown.year,
                        shown.rating.takeIf { it.isNotBlank() }?.let { "★ $it" } ?: "",
                        shown.category
                    ).filter { it.isNotBlank() }.joinToString("  •  ")
                    if (meta.isNotBlank()) Text(meta, fontSize = 15.sp, color = Gold)
                    if (shown.description.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(shown.description, fontSize = 15.sp, color = Color(0xFFDDDDEE), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }

        Greeting(
            Modifier
                .align(Alignment.TopStart)
                .padding(24.dp)
        )

        Row(
            Modifier
                .align(Alignment.BottomStart)
                .padding(start = 32.dp, bottom = 22.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TvButton("تشغيل", onPlay, icon = Icons.Filled.PlayArrow, primary = true)
            if (item.type == ContentType.MOVIE || item.type == ContentType.SERIES) {
                TvButton("التفاصيل", onOpen, icon = Icons.Filled.Info)
            }
        }
    }
}

/** ترحيب وساعة */
@Composable
fun Greeting(modifier: Modifier = Modifier) {
    var now by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(20_000)
            now = Calendar.getInstance()
        }
    }
    val hour = now.get(Calendar.HOUR_OF_DAY)
    val greet = when (hour) {
        in 4..11 -> "صباح الخير"
        in 12..17 -> "يسعد مساك"
        else -> "مساء الخير"
    }
    val time = SimpleDateFormat("h:mm a", Locale("ar")).format(now.time)
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = 0.45f))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text("$greet يا أبو معاذ", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(time, fontSize = 14.sp, color = Gold)
    }
}
