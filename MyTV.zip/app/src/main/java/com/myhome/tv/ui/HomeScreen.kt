package com.myhome.tv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.myhome.tv.AppViewModel
import com.myhome.tv.Tab
import com.myhome.tv.data.ContentItem
import com.myhome.tv.data.ContentType

@Composable
fun HomeScreen(
    vm: AppViewModel,
    tab: Tab,
    onOpen: (ContentItem) -> Unit,
    onPlay: (ContentItem) -> Unit,
    onAdd: () -> Unit
) {
    val all = vm.items.sortedByDescending { it.addedAt }
    val list = when (tab) {
        Tab.HOME -> all
        Tab.MOVIES -> all.filter { it.type == ContentType.MOVIE }
        Tab.SERIES -> all.filter { it.type == ContentType.SERIES }
        Tab.CHANNELS -> all.filter { it.type == ContentType.CHANNEL }
    }
    if (list.isEmpty()) {
        EmptyState(
            title = "ما فيه محتوى هنا بعد",
            subtitle = "روح لقسم \"إدارة المحتوى\" وأضف أول فيلم أو مسلسل أو قناة",
            action = "إضافة محتوى",
            onAction = onAdd
        )
        return
    }
    val featured = list.firstOrNull { it.type != ContentType.CHANNEL && (it.backdrop.isNotBlank() || it.poster.isNotBlank()) }
        ?: list.first()
    val continueList = if (tab == Tab.HOME) vm.continueWatching() else emptyList()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 48.dp)) {
        item(key = "hero") {
            Hero(featured, onPlay = { onPlay(featured) }, onOpen = { onOpen(featured) })
        }
        if (tab == Tab.HOME) {
            if (continueList.isNotEmpty()) {
                item(key = "continue") { ContentRow("تابع المشاهدة", continueList, vm, onOpen) }
            }
            val channels = list.filter { it.type == ContentType.CHANNEL }
            if (channels.isNotEmpty()) item(key = "channels") { ContentRow("القنوات المباشرة", channels.take(40), vm, onOpen) }
            val movies = list.filter { it.type == ContentType.MOVIE }
            if (movies.isNotEmpty()) item(key = "movies") { ContentRow("أحدث الأفلام", movies.take(40), vm, onOpen) }
            val series = list.filter { it.type == ContentType.SERIES }
            if (series.isNotEmpty()) item(key = "series") { ContentRow("المسلسلات", series.take(40), vm, onOpen) }
            list.filter { it.type != ContentType.CHANNEL && it.category.isNotBlank() }
                .groupBy { it.category }
                .forEach { (cat, l) -> item(key = "cat_$cat") { ContentRow(cat, l, vm, onOpen) } }
        } else {
            list.groupBy { it.category.ifBlank { "الكل" } }
                .forEach { (cat, l) -> item(key = "cat_$cat") { ContentRow(cat, l, vm, onOpen) } }
        }
    }
}

@Composable
fun ContentRow(title: String, list: List<ContentItem>, vm: AppViewModel, onClick: (ContentItem) -> Unit) {
    Column(Modifier.padding(top = 12.dp)) {
        SectionTitle(title, Modifier.padding(horizontal = 32.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 32.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            items(list, key = { it.id }) { item ->
                ContentCard(item, vm.movieFraction(item), onClick = { onClick(item) })
            }
        }
    }
}

@Composable
fun Hero(item: ContentItem, onPlay: () -> Unit, onOpen: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(360.dp)
    ) {
        val img = item.backdrop.ifBlank { item.poster }
        if (img.isNotBlank()) {
            AsyncImage(
                model = img,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Accent, Bg))))
        }
        // تظليل عشان النص يبان
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Bg))))
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Transparent, Bg.copy(alpha = 0.92f)))))

        Column(
            Modifier
                .align(Alignment.BottomStart)
                .padding(32.dp)
                .fillMaxWidth(0.55f)
        ) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Accent)
                    .padding(horizontal = 10.dp, vertical = 3.dp)
            ) {
                Text(item.type.single, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Spacer(Modifier.height(10.dp))
            Text(item.title, fontSize = 40.sp, fontWeight = FontWeight.Black, color = Color.White, maxLines = 2)
            val meta = listOf(item.year, item.rating.takeIf { it.isNotBlank() }?.let { "★ $it" } ?: "", item.category)
                .filter { it.isNotBlank() }.joinToString("  •  ")
            if (meta.isNotBlank()) Text(meta, fontSize = 15.sp, color = TextDim)
            if (item.description.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(item.description, fontSize = 15.sp, color = Color(0xFFDDDDEE), maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TvButton("تشغيل", onPlay, icon = Icons.Filled.PlayArrow, primary = true)
                if (item.type != ContentType.CHANNEL) TvButton("التفاصيل", onOpen, icon = Icons.Filled.Info)
            }
        }
    }
}
